<?php
/**
 * The template for displaying all single posts
 *
 * @package Bug_Mohol
 */

get_header();
?>

<main id="primary" class="site-main py-5">
    <div class="container">
        <?php bug_mohol_breadcrumbs(); ?>
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <?php
                while (have_posts()):
                    the_post();
                    ?>

                    <article id="post-<?php the_ID(); ?>" <?php post_class('single-post-area'); ?>>

                        <header class="entry-header mb-4 text-center">
                            <!-- Category -->
                            <div class="entry-meta mb-3">
                                <a href="<?php echo esc_url(get_category_link(get_the_category()[0]->term_id)); ?>" class="text-uppercase fw-bold samakal-category-link" style="color: #0056b3; letter-spacing: 1px; font-size: 1rem; text-decoration: none;">
                                    <?php
                                    $categories = get_the_category();
                                    if (!empty($categories)) {
                                        echo esc_html($categories[0]->name);
                                    }
                                    ?>
                                </a>
                            </div><!-- .entry-meta -->

                            <!-- Title -->
                            <?php the_title('<h1 class="entry-title fw-bold mb-4 samakal-single-title" style="font-size: 2.5rem; line-height: 1.4; color: #111;">', '</h1>'); ?>

                            <!-- Author, Date & Text Resize -->
                            <div class="d-flex flex-column flex-md-row align-items-center justify-content-between border-top border-bottom py-3 mb-4 text-muted small gap-3">
                                <div class="entry-meta d-flex justify-content-center align-items-center flex-wrap gap-2 gap-md-3">
                                    <span class="d-flex align-items-center">
                                        <i class="fas fa-user-circle me-1 fs-6 text-primary"></i> 
                                        <span class="fw-bold text-dark"> <?php the_author(); ?></span>
                                    </span>
                                    <span class="d-none d-sm-inline">&bull;</span>
                                    <span>
                                        <i class="far fa-clock me-1"></i> <?php echo get_the_date(); ?>
                                    </span>
                                    <span class="d-none d-sm-inline">&bull;</span>
                                    <span>
                                        <i class="far fa-comments me-1"></i> <?php comments_number('0 মন্তব্য', '1 মন্তব্য', '% মন্তব্য'); ?>
                                    </span>
                                </div>
                                <div class="text-resize d-flex align-items-center justify-content-center gap-2 bg-light px-3 py-2 rounded-pill shadow-sm">
                                    <span class="fw-bold text-uppercase me-1" style="letter-spacing: 0.5px; font-size: 0.8rem;">ফন্ট সাইজ:</span>
                                    <button type="button" class="btn btn-sm btn-outline-secondary rounded-circle d-flex align-items-center justify-content-center border-0 bg-white shadow-sm" onclick="changeFontSize(-1)" title="ছোট করুন" style="width: 26px; height: 26px; padding: 0;">
                                        <i class="fas fa-minus" style="font-size: 10px;"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary rounded-circle d-flex align-items-center justify-content-center border-0 shadow-sm bg-white" onclick="changeFontSize(1)" title="বড় করুন" style="width: 28px; height: 28px; padding: 0;">
                                        <i class="fas fa-plus" style="font-size: 10px;"></i>
                                    </button>
                                </div>
                            </div><!-- .entry-meta -->
                        </header><!-- .entry-header -->

                        <!-- Featured Image -->
                        <?php if (has_post_thumbnail()): ?>
                            <div class="post-thumbnail mb-4 text-center">
                                <?php the_post_thumbnail('full', array('class' => 'img-fluid rounded shadow-sm w-100')); ?>
                            </div><!-- .post-thumbnail -->
                        <?php endif; ?>

                        <?php
                        // Post Top Ad Slot
                        if ( function_exists( 'bug_mohol_render_ad_slot' ) ) {
                            bug_mohol_render_ad_slot( 'bug_mohol_ad_post_top', 'আর্টিকেল শীর্ষ বিজ্ঞাপন', 'responsive' );
                        }
                        ?>

                        <!-- Content -->
                        <div id="samakal-article-content" class="entry-content" style="font-size: 1.15rem; line-height: 1.9; color: #333; font-weight: 400;">
                            <?php
                            the_content();

                            wp_link_pages(
                                array(
                                    'before' => '<div class="page-links mt-4 fw-bold">' . esc_html__('Pages:', 'bug-mohol'),
                                    'after' => '</div>',
                                    'link_before' => '<span class="page-number px-2 py-1 bg-light border rounded ms-2">',
                                    'link_after'  => '</span>',
                                )
                            );
                            ?>
                        </div><!-- #samakal-article-content -->

                        <!-- Elegant Social Share Buttons (At the end of content) -->
                        <div class="premium-post-share-bar d-flex flex-wrap align-items-center justify-content-between border-top border-bottom py-3 my-4 gap-3">
                            <div class="share-label fw-bold text-dark small text-uppercase" style="letter-spacing: 0.5px; font-size: 0.95rem;">আর্টিকেলটি শেয়ার করুন:</div>
                            <div class="d-flex align-items-center gap-2">
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary share-btn-round facebook-color" title="ফেইসবুকে শেয়ার করুন">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-info share-btn-round twitter-color" title="টুইটারে শেয়ার করুন">
                                    <i class="fab fa-x-twitter"></i>
                                </a>
                                <a href="https://api.whatsapp.com/send?text=<?php echo urlencode(get_the_title() . ' - ' . get_permalink()); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-success share-btn-round whatsapp-color" title="হোয়াটসঅ্যাপে শেয়ার করুন">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                                <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary share-btn-round linkedin-color" title="লিংকডইনে শেয়ার করুন">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                                <button onclick="navigator.clipboard.writeText('<?php echo get_permalink(); ?>'); showCopyToast();" class="btn btn-sm btn-outline-secondary share-btn-round" title="লিংক কপি করুন">
                                    <i class="fas fa-link"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Professional Premium Author Card -->
                        <div class="premium-author-card p-4 mb-5 rounded-4 shadow-sm border bg-white">
                            <div class="row align-items-center g-4">
                                <div class="col-md-3 col-sm-4 text-center">
                                    <div class="position-relative d-inline-block author-avatar-wrapper">
                                        <?php echo get_avatar( get_the_author_meta( 'ID' ), 110, '', get_the_author(), array('class' => 'rounded-circle shadow-sm border author-avatar-zoom') ); ?>
                                        <span class="position-absolute bottom-0 end-0 bg-primary text-white rounded-circle d-flex align-items-center justify-content-center verified-badge shadow animate-pulse" style="width: 26px; height: 26px; border: 2px solid #fff;" title="Verified Writer">
                                            <i class="fas fa-check" style="font-size: 11px;"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-9 col-sm-8 text-center text-sm-start">
                                    <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2 mb-2">
                                        <div>
                                            <h4 class="h5 fw-bold text-dark mb-1 d-inline-flex align-items-center gap-2">
                                                <?php the_author_posts_link(); ?>
                                            </h4>
                                            <span class="badge bg-light border text-primary rounded-pill px-3 py-1 font-weight-bold" style="font-size: 0.78rem; letter-spacing: 0.5px;">বিশেষ প্রতিনিধি</span>
                                        </div>
                                        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1 fw-bold" style="font-size: 0.8rem;">
                                            <i class="fas fa-newspaper me-1"></i> সব লেখা (<?php echo count_user_posts( get_the_author_meta( 'ID' ) ); ?>)
                                        </a>
                                    </div>
                                    <p class="author-bio text-secondary mb-3" style="font-size: 0.95rem; line-height: 1.6;">
                                        <?php 
                                        $author_bio = get_the_author_meta( 'description' );
                                        if ( !empty( $author_bio ) ) {
                                            echo esc_html( $author_bio );
                                        } else {
                                            echo esc_html( 'এই লেখকের কোনো জীবনবৃত্তান্ত বা সংক্ষিপ্ত বর্ণনা যুক্ত করা হয়নি। লেখকের আরও লেখা দেখতে এবং অনুসরণ করতে সব লেখা লিংকে ক্লিক করুন।' );
                                        }
                                        ?>
                                    </p>
                                    <div class="d-flex align-items-center justify-content-center justify-content-sm-start gap-3 author-social-links">
                                        <?php
                                        $website = get_the_author_meta('user_url');
                                        $email = get_the_author_meta('user_email');
                                        $facebook = get_the_author_meta('facebook');
                                        $twitter = get_the_author_meta('twitter');
                                        
                                        if ( !empty( $facebook ) ) : ?>
                                            <a href="<?php echo esc_url( $facebook ); ?>" target="_blank" rel="noopener noreferrer" class="social-icon-round text-primary" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                                        <?php endif;
                                        if ( !empty( $twitter ) ) : ?>
                                            <a href="<?php echo esc_url( $twitter ); ?>" target="_blank" rel="noopener noreferrer" class="social-icon-round text-info" title="Twitter"><i class="fab fa-x-twitter"></i></a>
                                        <?php endif;
                                        if ( !empty( $website ) ) : ?>
                                            <a href="<?php echo esc_url( $website ); ?>" target="_blank" rel="noopener noreferrer" class="social-icon-round text-secondary" title="Website"><i class="fas fa-globe"></i></a>
                                        <?php endif;
                                        if ( !empty( $email ) ) : ?>
                                            <a href="mailto:<?php echo esc_attr( $email ); ?>" class="social-icon-round text-danger" title="Email"><i class="far fa-envelope"></i></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        // Post Bottom Ad Slot
                        if ( function_exists( 'bug_mohol_render_ad_slot' ) ) {
                            bug_mohol_render_ad_slot( 'bug_mohol_ad_post_bottom', 'আর্টিকেল নিম্ন বিজ্ঞাপন', 'responsive' );
                        }
                        ?>

                    </article><!-- #post-## -->

                    <section class="related-posts mt-5 pt-5 border-top">
                        <h3 class="h4 fw-bold mb-4"><?php esc_html_e('সংশ্লিষ্ট খবর', 'bug-mohol'); ?></h3>

                        <?php
                        $categories = get_the_category($post->ID);
                        if ($categories) {
                            $category_ids = array();
                            foreach ($categories as $individual_category)
                                $category_ids[] = $individual_category->term_id;

                            $args = array(
                                'category__in' => $category_ids,
                                'post__not_in' => array($post->ID),
                                'posts_per_page' => 3, // Fetch 3 related posts
                                'ignore_sticky_posts' => true
                            );

                            $my_query = new wp_query($args);

                            if ($my_query->have_posts()) {
                                echo '<div class="row g-4">';
                                while ($my_query->have_posts()) {
                                    $my_query->the_post();
                                    ?>
                                     <div class="col-md-4">
                                         <article class="category-post-grid h-100 group-hover-underline">
                                             <div class="position-relative overflow-hidden rounded-3 mb-3">
                                                 <a href="<?php the_permalink(); ?>" class="d-block image-scale-hover">
                                                     <?php if (has_post_thumbnail()): ?>
                                                         <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>"
                                                             class="w-100 bg-light" alt="<?php the_title_attribute(); ?>"
                                                             style="height: 150px; object-fit: cover;" loading="lazy">
                                                     <?php else: ?>
                                                         <div class="w-100 bg-secondary d-flex align-items-center justify-content-center text-white"
                                                             style="height: 150px; opacity: 0.1;">
                                                             <i class="fas fa-image fa-2x"></i>
                                                         </div>
                                                     <?php endif; ?>
                                                 </a>
                                             </div>
                                             <div class="p-0">
                                                 <h4 class="h6 fw-bold mb-0 line-clamp-2" style="font-size: 1.1rem; line-height: 1.4;">
                                                     <a href="<?php the_permalink(); ?>" class="post-title-link">
                                                         <?php the_title(); ?>
                                                     </a>
                                                 </h4>
                                             </div>
                                         </article>
                                     </div>
                                    <?php
                                }
                                echo '</div>';
                            } else {
                                echo '<p class="text-muted">কোনো সংশ্লিষ্ট খবর পাওয়া যায়নি।</p>';
                            }
                        }
                        wp_reset_postdata();
                        ?>
                    </section>

                    <?php
                    // If comments are open or we have at least one comment, load up the comment template.
                    if (comments_open() || get_comments_number()):
                        comments_template();
                    endif;

                endwhile; // End of the loop.
                ?>

            </div><!-- .col-lg-8 -->
        </div><!-- .row -->
    </div><!-- .container -->
</main><!-- #main -->

<?php
get_footer();
?>

<!-- Premium Copy Toast Notification -->
<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1080;">
  <div id="copyToast" class="toast align-items-center text-white bg-dark border-0 rounded-pilled shadow-lg" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex px-1 py-1">
      <div class="toast-body d-flex align-items-center gap-2" style="font-size: 0.95rem; font-weight: 500;">
        <i class="fas fa-check-circle text-success fs-5"></i> লিংক সফলভাবে কপি করা হয়েছে!
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>

<script>
    // Text Resizer Script
    function changeFontSize(step) {
        const contentArea = document.getElementById('samakal-article-content');
        if (!contentArea) return;
        
        let currentSize = parseFloat(window.getComputedStyle(contentArea, null).getPropertyValue('font-size'));
        
        // Define boundaries (e.g. min 14px, max 32px) to prevent breaking layout
        let newSize = currentSize + (step * 2); 
        if (newSize < 14) newSize = 14;
        if (newSize > 32) newSize = 32;

        contentArea.style.fontSize = newSize + 'px';
        localStorage.setItem('bugmohol_font_size', newSize);
    }

    // Apply saved font size on load
    document.addEventListener("DOMContentLoaded", function() {
        const savedSize = localStorage.getItem('bugmohol_font_size');
        if (savedSize) {
            const contentArea = document.getElementById('samakal-article-content');
            if (contentArea) {
                contentArea.style.fontSize = savedSize + 'px';
            }
        }
    });

    // Elegant Copy Toast Script
    function showCopyToast() {
        const toastEl = document.getElementById('copyToast');
        if (toastEl) {
            const toast = new bootstrap.Toast(toastEl, {
                delay: 3000 // Display for 3 seconds seamlessly
            });
            toast.show();
        }
    }
</script>
