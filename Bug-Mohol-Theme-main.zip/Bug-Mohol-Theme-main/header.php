<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bug_Mohol
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text d-none" href="#primary"><?php esc_html_e( 'Skip to content', 'bug-mohol' ); ?></a>

	<header id="masthead" class="site-header">
		
		<!-- Image Match Top Bar -->
		<div class="header-top py-3 py-lg-4 bg-white">
			<div class="container">
				<div class="row align-items-center">
					
					<!-- Left: Location, Weather & Date (Matching Image) -->
					<div class="col-lg-5 col-md-12 d-flex align-items-center justify-content-center justify-content-lg-start gap-2 mb-3 mb-lg-0">
						<div class="d-flex align-items-center gap-2">
							<i class="fas fa-map-marker-alt text-danger"></i>
							<span class="fw-bold text-dark" style="font-size: 15px;">ঢাকা</span>
							<span id="dhaka-weather" class="small text-secondary d-flex align-items-center gap-1 border-start ps-2" style="font-size: 14px; border-color: rgba(0,0,0,0.1) !important; cursor: default;" title="ঢাকা রিয়েল-টাইম তাপমাত্রা">
								<i class="fas fa-spinner fa-spin text-primary" style="font-size: 11px;"></i> <span class="weather-temp">--°সে.</span>
							</span>
						</div>
						<div class="vr mx-2 bg-secondary opacity-50" style="height: 20px; width: 1.5px;"></div>
						<div class="d-flex align-items-center gap-2 text-muted live-bangla-clock" style="font-size: 14px;">
							<i class="far fa-calendar-alt"></i>
							<span><?php echo bug_mohol_bangla_date(date_i18n('l, d F Y')); ?></span>
						</div>
					</div>

					<!-- Center: Logo (Matching Image) -->
					<div class="col-lg-2 col-12 text-center mb-3 mb-lg-0">
						<div class="site-branding">
							<?php
							if ( has_custom_logo() ) :
								the_custom_logo();
							else :
								?>
								<h1 class="site-title m-0">
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="text-dark text-decoration-none site-title-image-match">
										<?php bloginfo( 'name' ); ?>
									</a>
								</h1>
							<?php endif; ?>
						</div>
					</div>

					<!-- Right: Social & Button (Matching Image) -->
					<div class="col-lg-5 col-md-12 d-flex justify-content-center justify-content-lg-end align-items-center gap-3">
						<div class="header-social-links-match d-flex gap-2">
							<a href="#" class="social-circle-match"><i class="fab fa-facebook-f"></i></a>
							<a href="#" class="social-circle-match">
								<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
									<path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"/>
								</svg>
							</a>
							<a href="#" class="social-circle-match"><i class="fab fa-linkedin-in"></i></a>
							<a href="#" class="social-circle-match"><i class="fab fa-youtube"></i></a>
							<a href="#" class="social-circle-match"><i class="fab fa-instagram"></i></a>
							<a href="#" class="social-circle-match"><i class="fab fa-whatsapp"></i></a>
						</div>
						<div class="language-switcher-pro d-flex align-items-center notranslate">
							<a href="#" class="btn-lang-match bn" data-lang="bn">বাংলা</a>
							<a href="#" class="btn-lang-match en" data-lang="en">English</a>
						</div>
					</div>

				</div>
			</div>
		</div>

		<!-- Main Navigation Bar -->
		<nav id="site-navigation" class="navbar navbar-expand-lg navbar-light bg-white py-0 sticky-top image-match-navbar border-top border-bottom">
			<div class="container position-relative">
				
				<!-- Mobile Header -->
				<div class="d-flex d-lg-none w-100 justify-content-between align-items-center py-2 px-2">
					<div class="d-flex align-items-center gap-2">
						<button class="navbar-toggler border-0 p-0 shadow-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#primary-navbar">
							<i class="fas fa-bars-staggered fs-3"></i>
						</button>

					</div>
					<div class="mobile-logo-match d-flex align-items-center">
						<?php if ( has_custom_logo() ) : ?>
							<?php the_custom_logo(); ?>
						<?php else : ?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-dark text-decoration-none fw-bold fs-4 site-title-image-match" style="font-size: 24px !important;">
								<?php bloginfo( 'name' ); ?>
							</a>
						<?php endif; ?>
					</div>
					<a href="#searchOffcanvas" data-bs-toggle="offcanvas" class="text-dark"><i class="fas fa-search"></i></a>
				</div>

				<!-- Desktop Menu Centered -->
				<div class="collapse navbar-collapse w-100">
					<div class="d-flex justify-content-center w-100">
						<?php
						if ( has_nav_menu( 'primary' ) ) {
							wp_nav_menu( array(
								'theme_location'  => 'primary',
								'menu_id'         => 'primary-menu-desktop',
								'container'       => false,
								'menu_class'      => 'navbar-nav image-match-nav-links',
								'fallback_cb'     => 'wp_page_menu',
								'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
								'depth'           => 1,
								'walker'          => new Bootstrap_5_WP_Nav_Walker(),
							) );
						}
						?>
					</div>

					<!-- Icons on right -->
					<div class="nav-icons-right d-none d-lg-flex align-items-center gap-3 ms-auto" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%);">

						<a href="#searchOffcanvas" data-bs-toggle="offcanvas" class="text-dark hover-primary"><i class="fas fa-search"></i></a>
						<button id="darkModeToggle" class="btn btn-link p-0 text-dark border-0 shadow-none hover-primary">
							<i id="themeIcon" class="fas fa-moon"></i>
						</button>
					</div>
				</div>

			</div>
		</nav>

		<!-- Offcanvas Menu Drawer for Mobile -->
		<div class="offcanvas offcanvas-start" tabindex="-1" id="primary-navbar">
			<div class="offcanvas-header border-bottom py-3 px-4 d-flex align-items-center justify-content-between">
				<h5 class="offcanvas-title fw-bold site-title-image-match m-0 d-flex align-items-center" id="primaryNavbarLabel">
					<?php if ( has_custom_logo() ) : ?>
						<?php the_custom_logo(); ?>
					<?php else : ?>
						<?php bloginfo( 'name' ); ?>
					<?php endif; ?>
				</h5>
				<button type="button" class="btn-close shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			</div>
			<div class="offcanvas-body p-0">
				<div class="mobile-menu-container">
					<?php
					if ( has_nav_menu( 'primary' ) ) {
						wp_nav_menu( array(
							'theme_location'  => 'primary',
							'menu_id'         => 'primary-menu-mobile',
							'container'       => false,
							'menu_class'      => 'navbar-nav mobile-nav-links w-100',
							'fallback_cb'     => 'wp_page_menu',
							'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
							'depth'           => 2,
							'walker'          => new Bootstrap_5_WP_Nav_Walker(),
						) );
					}
					?>
				</div>
				
				<!-- Mobile Sidebar Footer Actions -->
				<div class="offcanvas-footer mt-auto border-top p-4 bg-light">
					<div class="row text-center align-items-center">
						<div class="col-4 border-end">
							<button id="darkModeToggleMobile" class="btn btn-link text-dark text-decoration-none shadow-none flex-column d-flex align-items-center justify-content-center gap-2 w-100 p-0 border-0" style="background: none;">
								<i class="fas fa-moon"></i>
								<span class="small fw-bold">ডার্ক মোড</span>
							</button>
						</div>
						<div class="col-4 border-end">
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-link text-dark text-decoration-none shadow-none flex-column d-flex align-items-center justify-content-center gap-2 w-100 p-0">
								<i class="fas fa-home"></i>
								<span class="small fw-bold">প্রচ্ছদ</span>
							</a>
						</div>
						<div class="col-4">
							<div class="d-flex flex-column align-items-center justify-content-center gap-2 w-100">
								<i class="fas fa-globe text-secondary" style="font-size: 15px;"></i>
								<div class="language-switcher-pro notranslate" style="padding: 2px;">
									<a href="#" class="btn-lang-match bn" style="font-size: 10px; padding: 3px 8px;" data-lang="bn">বাং</a>
									<a href="#" class="btn-lang-match en" style="font-size: 10px; padding: 3px 8px;" data-lang="en">EN</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</header><!-- #masthead -->

	<?php
	// Dynamic Global Header Ad Slot
	if ( function_exists( 'bug_mohol_render_ad_slot' ) ) {
		echo '<div class="container ad-header-slot-container">';
		bug_mohol_render_ad_slot( 'bug_mohol_ad_header', 'হেডার বিজ্ঞাপন', '728 x 90' );
		echo '</div>';
	}
	?>

	<!-- Full Screen Search Overlay -->
	<div class="offcanvas offcanvas-top search-overlay" tabindex="-1" id="searchOffcanvas" style="height: auto;">
		<div class="offcanvas-header container py-3">
			<h5 class="offcanvas-title fw-bold" id="searchOffcanvasLabel">অনুসন্ধান করুন</h5>
			<button type="button" class="btn-close ms-auto shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
		</div>
		<div class="offcanvas-body container py-5 d-flex align-items-center justify-content-center">
			<form role="search" method="get" class="search-form w-100" style="max-width: 800px;" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<div class="input-group search-input-group shadow-sm rounded-pill overflow-hidden border">
					<input type="search" class="form-control border-0 px-4 py-3 shadow-none" placeholder="কী খুঁজতে চাইছেন?" value="<?php echo get_search_query(); ?>" name="s" required>
					<button class="btn btn-primary border-0 px-4" type="submit"><i class="fas fa-search"></i> খুঁজুন</button>
				</div>
			</form>
		</div>
	</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const weatherContainer = document.getElementById("dhaka-weather");
    if (!weatherContainer) return;

    const tempElement = weatherContainer.querySelector(".weather-temp");
    const iconElement = weatherContainer.querySelector("i");

    const weatherIcons = {
        0: "fa-sun text-warning",
        1: "fa-cloud-sun text-warning",
        2: "fa-cloud-sun text-secondary",
        3: "fa-cloud text-secondary",
        45: "fa-smog text-secondary",
        48: "fa-smog text-secondary",
        51: "fa-cloud-showers-heavy text-info",
        53: "fa-cloud-showers-heavy text-info",
        55: "fa-cloud-showers-heavy text-info",
        61: "fa-cloud-rain text-primary",
        63: "fa-cloud-rain text-primary",
        65: "fa-cloud-rain text-primary",
        80: "fa-cloud-showers-water text-primary",
        81: "fa-cloud-showers-water text-primary",
        82: "fa-cloud-showers-water text-primary",
        95: "fa-cloud-bolt text-danger",
        96: "fa-cloud-bolt text-danger",
        99: "fa-cloud-bolt text-danger"
    };

    function toBanglaDigits(num) {
        const banglaDigits = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
        return num.toString().replace(/\d/g, d => banglaDigits[d]);
    }

    fetch("https://api.open-meteo.com/v1/forecast?latitude=23.8103&longitude=90.4125&current=temperature_2m,weather_code")
        .then(response => {
            if (!response.ok) throw new Error("Weather service not available");
            return response.json();
        })
        .then(data => {
            if (data && data.current) {
                const temp = Math.round(data.current.temperature_2m);
                const code = data.current.weather_code;
                
                tempElement.textContent = toBanglaDigits(temp) + "°সে.";
                
                let iconClass = weatherIcons[code] || "fa-cloud-sun text-warning";
                iconElement.className = "fas " + iconClass;
                iconElement.style.fontSize = "14px";
            }
        })
        .catch(error => {
            console.warn("Weather fetch failed, falling back safely: ", error);
            tempElement.textContent = toBanglaDigits(30) + "°সে.";
            iconElement.className = "fas fa-sun text-warning";
            iconElement.style.fontSize = "14px";
        });
});
</script>
