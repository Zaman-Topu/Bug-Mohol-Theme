document.addEventListener("DOMContentLoaded", () => {
  const toggleBtns = document.querySelectorAll("#darkModeToggle, #darkModeToggleMobile");
  const body = document.body;
  const themeIcons = document.querySelectorAll("#themeIcon, #darkModeToggleMobile i");

  function updateThemeUI(isDark) {
    themeIcons.forEach(icon => {
      icon.className = isDark ? "fas fa-sun" : "fas fa-moon";
    });
    
    // Update mobile text if it exists
    const mobileText = document.querySelector(".dark-mode-text");
    if (mobileText) {
      mobileText.textContent = isDark ? "লাইট মোড" : "ডার্ক মোড";
    }
  }

  // Check local storage for dark mode preference
  if (localStorage.getItem("theme") === "dark") {
    body.classList.add("dark-mode");
    updateThemeUI(true);
  } else {
    updateThemeUI(false);
  }

  toggleBtns.forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      body.classList.toggle("dark-mode");
      const isDark = body.classList.contains("dark-mode");
      localStorage.setItem("theme", isDark ? "dark" : "light");
      updateThemeUI(isDark);
    });
  });

  // Live Bangla Date and Time Clock
  const banglaDigits = {
    0: "০",
    1: "১",
    2: "২",
    3: "৩",
    4: "৪",
    5: "৫",
    6: "৬",
    7: "৭",
    8: "৮",
    9: "৯",
  };
  const banglaDays = [
    "রবিবার",
    "সোমবার",
    "মঙ্গলবার",
    "বুধবার",
    "বৃহস্পতিবার",
    "শুক্রবার",
    "শনিবার",
  ];
  const banglaMonths = [
    "জানুয়ারি",
    "ফেব্রুয়ারি",
    "মার্চ",
    "এপ্রিল",
    "মে",
    "জুন",
    "জুলাই",
    "আগস্ট",
    "সেপ্টেম্বর",
    "অক্টোবর",
    "নভেম্বর",
    "ডিসেম্বর",
  ];

  function translateToBangla(str) {
    return str.toString().replace(/[0-9]/g, function (w) {
      return banglaDigits[w];
    });
  }

  function updateBanglaTime() {
    const clocks = document.querySelectorAll(".live-bangla-clock");
    if (clocks.length === 0) return;

    const now = new Date();
    const dayName = banglaDays[now.getDay()];
    const day = translateToBangla(String(now.getDate()).padStart(2, "0"));
    const monthName = banglaMonths[now.getMonth()];
    const year = translateToBangla(now.getFullYear());

    // Format: সোমবার, ০৯ মার্চ ২০২৬
    const timeString = `${dayName}, ${day} ${monthName} ${year}`;

    clocks.forEach((clock) => {
      clock.innerHTML = `<i class="far fa-calendar-alt me-1 text-muted"></i> ${timeString}`;
    });
  }

  // Update every minute (no need to tick every second if it's only a date)
  setInterval(updateBanglaTime, 60000);
  updateBanglaTime(); // Initial call

  // Sidebar Tab Widget Logic
  const tabBtns = document.querySelectorAll(".tab-btn");
  if (tabBtns.length > 0) {
    tabBtns.forEach((btn) => {
      btn.addEventListener("click", function () {
        // Remove active classes
        tabBtns.forEach((b) => b.classList.remove("active", "text-primary"));
        document.querySelectorAll(".tab-pane").forEach((p) => {
          p.classList.remove("active", "show");
          p.classList.add("d-none");
        });

        // Add active to current
        this.classList.add("active", "text-primary");
        const targetPane = document.getElementById(
          this.getAttribute("data-target"),
        );
        if (targetPane) {
          targetPane.classList.remove("d-none");
          // Add slight delay for animation
          setTimeout(() => {
            targetPane.classList.add("active", "show");
          }, 50);
        }
      });
    });
  }

  // --- Sticky Navbar Logic ---
  const siteNav = document.getElementById("site-navigation");
  const stickyContainer = document.querySelector(".header-branding-bar");

  if (siteNav && stickyContainer) {
    window.addEventListener("scroll", () => {
      // Calculate offset to fix nav when header main scrolls out (utility bar + branding bar)
      const stickyOffset = stickyContainer.offsetTop + stickyContainer.offsetHeight;

      if (window.scrollY > stickyOffset) {
        siteNav.classList.add("is-sticky");
      } else {
        siteNav.classList.remove("is-sticky");
      }
    });
  }

  // --- Client-Side Language Switcher Logic (Bangla <-> English) ---
  const langButtons = document.querySelectorAll(".btn-lang-match");
  
  if (langButtons.length > 0) {
    const getCookie = (name) => {
      const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
      if (match) return match[2];
      return null;
    };

    const setCookie = (name, value, days) => {
      let expires = "";
      if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
      }
      
      // 1. Set host-only cookie (highly safe on localhost, IPs, and regular domains)
      document.cookie = `${name}=${value || ""}${expires}; path=/;`;
      
      // 2. Set wildcard subdomain cookie if valid domain
      const host = location.hostname;
      if (host.includes('.') && !/^[0-9.]+$/.test(host) && !host.endsWith('.local')) {
        const domain = host.split('.').slice(-2).join('.');
        document.cookie = `${name}=${value || ""}${expires}; path=/; domain=.${domain}`;
      }
    };

    const currentLang = getCookie("googtrans");
    // Robust check if language cookie contains English target (matches /bn/en, /auto/en, etc.)
    const isEnglish = (currentLang && currentLang.includes("/en"));

    // Sync button UI active classes on load
    langButtons.forEach(btn => {
      const targetLang = btn.getAttribute("data-lang");
      if ((isEnglish && targetLang === "en") || (!isEnglish && targetLang === "bn")) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });

    langButtons.forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const targetLang = btn.getAttribute("data-lang");
        
        if (targetLang === "bn") {
          // Switch back to original Bangla: Clear cookies on root, subdomain levels, and wildcard domains
          setCookie("googtrans", "", -1);
          
          document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
          document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=" + location.hostname;
          
          const host = location.hostname;
          if (host.includes('.') && !/^[0-9.]+$/.test(host)) {
            const domain = host.split('.').slice(-2).join('.');
            document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=." + domain;
            document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=" + domain;
          }
        } else if (targetLang === "en") {
          // Switch to English translation: Set both host-only and wildcard cookies
          setCookie("googtrans", "/bn/en", 1);
        }
        
        window.location.reload();
      });
    });

    // --- Query Parameter Language Switcher Trigger (Crawler Friendly) ---
    const urlParams = new URLSearchParams(window.location.search);
    const urlLang = urlParams.get('lang');
    if (urlLang === 'en' || urlLang === 'bn') {
      const currentVal = getCookie("googtrans");
      const isCurrentlyEn = (currentVal && currentVal.includes("/en"));
      
      if (urlLang === 'en' && !isCurrentlyEn) {
        setCookie("googtrans", "/bn/en", 1);
        urlParams.delete('lang');
        const newSearch = urlParams.toString();
        const cleanPath = window.location.pathname + (newSearch ? '?' + newSearch : '');
        window.location.replace(cleanPath);
      } else if (urlLang === 'bn' && isCurrentlyEn) {
        setCookie("googtrans", "", -1);
        document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=" + location.hostname;
        const host = location.hostname;
        if (host.includes('.') && !/^[0-9.]+$/.test(host)) {
          const domain = host.split('.').slice(-2).join('.');
          document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=." + domain;
        }
        urlParams.delete('lang');
        const newSearch = urlParams.toString();
        const cleanPath = window.location.pathname + (newSearch ? '?' + newSearch : '');
        window.location.replace(cleanPath);
      }
    }
  }
});

