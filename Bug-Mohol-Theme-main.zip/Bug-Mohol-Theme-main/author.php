<?php
/**
 * The template for displaying author pages
 *
 * @package Bug_Mohol
 */

get_header();
?>

<main id="primary" class="site-main py-5">
    <div class="container">
        <?php bug_mohol_breadcrumbs(); ?>
        <!-- Author Profile Header -->
        <header class="author-header p-4 p-md-5 bg-light rounded shadow-sm mb-5 border">
            <div class="row align-items-center">
                <div class="col-md-auto text-center mb-3 mb-md-0">
                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 120, '', '', array( 'class' => 'rounded-circle shadow-sm border' ) ); ?>
                </div>
                <div class="col-md">
                    <span class="badge bg-primary mb-2">প্রতিবেদক</span>
                    <h1 class="page-title fw-bold mb-2"><?php echo get_the_author(); ?></h1>
                    
                    <?php if ( get_the_author_meta( 'description' ) ) : ?>
                        <div class="author-bio text-muted mb-3" style="max-width: 700px;">
                            <?php the_author_meta( 'description' ); ?>
                        </div>
                    <?php endif; ?>

                    <div class="author-social d-flex gap-3">
                        <?php if ( get_the_author_meta( 'user_url' ) ) : ?>
                            <a href="<?php echo esc_url( get_the_author_meta( 'user_url' ) ); ?>" class="text-dark"><i class="fas fa-globe me-1"></i> ওয়েবসাইট</a>
                        <?php endif; ?>
                        <span class="text-muted"><i class="fas fa-newspaper me-1"></i> মোট খবর: <?php echo count_user_posts( get_the_author_meta( 'ID' ) ); ?>টি</span>
                    </div>
                </div>
            </div>
        </header>

        <div class="row">
            <!-- Left Column: Author's Posts -->
            <div class="col-lg-8 pe-lg-4">
                <h2 class="h4 fw-bold mb-4 border-bottom pb-2"><?php echo get_the_author(); ?>-এর সব খবর:</h2>

                <div class="list-view-container">
                    <?php if ( have_posts() ) : ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                             <article id="post-<?php the_ID(); ?>" <?php post_class( 'list-view-post' ); ?>>
                                 <?php if ( has_post_thumbnail() ) : ?>
                                     <a href="<?php the_permalink(); ?>" class="list-view-thumb-link">
                                         <img src="<?php echo get_the_post_thumbnail_url( get_the_ID(), 'medium' ); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                                     </a>
                                 <?php else : ?>
                                     <div class="list-view-thumb-link bg-light d-flex align-items-center justify-content-center text-muted">
                                         <i class="fas fa-image fa-2x"></i>
                                     </div>
                                 <?php endif; ?>

                                 <div class="list-view-content">
                                     <div class="post-meta small text-muted mb-2">
                                         <span class="text-primary fw-bold me-2"><i class="fas fa-folder-open me-1"></i><?php the_category( ', ' ); ?></span>
                                         <span class="me-2">&bull;</span>
                                         <i class="far fa-calendar-alt me-1"></i> <?php echo bug_mohol_bangla_date(get_the_date()); ?>
                                     </div>
                                     <h3 class="h4 fw-bold mb-2">
                                         <a href="<?php the_permalink(); ?>" class="post-title-link"><?php the_title(); ?></a>
                                     </h3>
                                     <div class="entry-summary text-muted mb-0 small line-clamp-2">
                                         <?php echo wp_trim_words( get_the_excerpt(), 25, '...' ); ?>
                                     </div>
                                 </div>
                             </article>
                        <?php endwhile; ?>

                        <?php bug_mohol_pagination(); ?>

                    <?php else : ?>
                        <p>এই প্রতিবেদকের কোনো খবর পাওয়া যায়নি।</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Column: Sidebar -->
            <div class="col-lg-4 mt-5 mt-lg-0">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
