<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Bug_Mohol
 */

?>

<footer id="colophon" class="site-footer bg-light border-top">
    <div class="container pt-4 pb-2">
        <!-- Top Row: Links -->
        <div class="row mb-4 pb-3 border-bottom border-secondary-subtle">
            <div class="col-md-12">
                 <?php
                 // Horizontal menu for important links
                 wp_nav_menu(array(
                     'theme_location' => 'footer',
                     'container' => false,
                     'menu_class' => 'd-flex flex-wrap justify-content-center justify-content-md-start gap-3 list-unstyled m-0 footer-top-nav',
                     'fallback_cb' => false,
                 ));
                 ?>
            </div>
        </div>

        <!-- Middle Row: Editor Info & Contact -->
        <div class="row mb-4 pb-3 border-bottom border-secondary-subtle">
            <div class="col-md-6 mb-4 mb-md-0 pe-md-5">
                <!-- Editor Info -->
                <?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
                    <?php dynamic_sidebar( 'footer-1' ); ?>
                <?php else: ?>
                <div class="footer-editor-info text-muted small" style="font-size: 0.95rem; line-height: 1.8;">
                    <p class="mb-1"><strong class="text-dark fw-bold">সম্পাদক:</strong> <?php echo esc_html(get_theme_mod('bug_mohol_editor', 'তৌফিক জামান তপু')); ?> <span class="mx-2 text-secondary">|</span> <strong class="text-dark fw-bold">প্রকাশক:</strong> <?php echo esc_html(get_theme_mod('bug_mohol_publisher', 'তৌফিক জামান তপু')); ?></p>
                    <p class="mb-0"><?php bloginfo('name'); ?>-এর পক্ষে প্রকাশক কর্তৃক <?php echo esc_html(get_theme_mod('bug_mohol_press_info', 'বগড়া প্রেস ও প্রকাশনা ভবন, কারওয়ান বাজার, ঢাকা।')); ?> থেকে মুদ্রিত এবং <?php echo esc_html(get_theme_mod('bug_mohol_office_addr', '১২৩/এ, কারওয়ান বাজার, ঢাকা-১২১৫।')); ?> থেকে প্রকাশিত।</p>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-6 text-md-end text-muted small" style="font-size: 0.95rem; line-height: 1.8;">
                <!-- Contact Info -->
                <?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
                    <?php dynamic_sidebar( 'footer-2' ); ?>
                <?php else: ?>
                <p class="mb-1"><strong class="text-dark fw-bold">ই-মেইল:</strong> <?php echo esc_html(get_theme_mod('bug_mohol_contact_email', 'info@bugmohol.com')); ?></p>
                <p class="mb-0"><strong class="text-dark fw-bold">বিজ্ঞাপন:</strong> <span dir="ltr"><?php echo esc_html(get_theme_mod('bug_mohol_ads_phone', '+৮৮ ০১৯১১-১২৩৪৫৬')); ?></span> <span class="mx-2 text-secondary">|</span> <strong class="text-dark fw-bold">ই-মেইল:</strong> <?php echo esc_html(get_theme_mod('bug_mohol_ads_email', 'ads@bugmohol.com')); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Bottom Row: Social & Apps -->
        <div class="row align-items-center mb-3">
            <div class="col-md-4 mb-3 mb-md-0">
                <div class="d-flex align-items-center gap-3 justify-content-center justify-content-md-start">
                    <?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-4' ); ?>
                    <?php else: ?>
                    <span class="fw-bold text-dark small">সোশ্যাল মিডিয়া:</span>
                    <?php
                    $socials = array(
                        'facebook'  => array('icon' => '<i class="fab fa-facebook-f"></i>', 'class' => 'facebook', 'default' => '#'),
                        'youtube'   => array('icon' => '<i class="fab fa-youtube"></i>', 'class' => 'youtube', 'default' => '#'),
                        'twitter'   => array('icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16"><path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"/></svg>', 'class' => 'twitter', 'default' => '#'),
                        'instagram' => array('icon' => '<i class="fab fa-instagram"></i>', 'class' => 'instagram', 'default' => '#'),
                    );
                    foreach ($socials as $key => $social_info) {
                        $url = get_theme_mod("bug_mohol_{$key}_url", $social_info['default']);
                        if (!empty($url)) {
                            echo '<a href="' . esc_url($url) . '" class="social-icon-pro ' . $social_info['class'] . '" target="_blank">' . $social_info['icon'] . '</a>';
                        }
                    }
                    ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 text-center mb-4 mb-md-0">
                 <?php
                        if (has_custom_logo()):
                            the_custom_logo();
                        else:
                            ?>
                            <h2 class="h2 fw-bold mb-0 text-dark"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home" class="text-dark text-decoration-none" style="font-family: var(--heading-font); letter-spacing: -1px;">
                                    <?php bloginfo('name'); ?>
                                </a></h2>
                        <?php endif; ?>
            </div>
            <div class="col-md-4 text-center text-md-end">
                <div class="footer-important-links d-flex flex-wrap justify-content-center justify-content-md-end gap-2">
                    <?php if ( is_active_sidebar( 'footer-5' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-5' ); ?>
                    <?php else: ?>
                    <a href="#" class="footer-outline-link">আমাদের সম্পর্কে</a>
                    <a href="#" class="footer-outline-link">যোগাযোগ</a>
                    <a href="#" class="footer-outline-link">ব্যবহারের শর্তাবলি</a>
                    <a href="#" class="footer-outline-link">গোপনীয়তার নীতি</a>
                    <a href="#" class="footer-outline-link">বিজ্ঞাপন</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Very Bottom Copyright -->
    <div class="bg-white py-3 border-top border-secondary-subtle footer-copyright-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start small text-muted mb-2 mb-md-0" style="font-size: 0.85rem;">
                    স্বত্ব &copy; <?php echo bug_mohol_bangla_number(date('Y')); ?> <strong class="text-dark"><?php bloginfo('name'); ?></strong>। সর্বস্বত্ব সংরক্ষিত।
                </div>
                <div class="col-md-6 text-center text-md-end small text-muted" style="font-size: 0.85rem;">
                     Developed by <a href="#" class="text-dark text-decoration-none fw-medium hover-primary">Toufique Zaman Topu</a>
                </div>
            </div>
        </div>
    </div>
</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>

</html>