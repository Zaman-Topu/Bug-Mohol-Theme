<?php
/**
 * The main template file / fallback for blog
 *
 * @package Bug_Mohol
 */

get_header();
?>

<main id="primary" class="site-main py-5">
	<div class="container">
		<!-- Main Content Area & Sidebar -->
		<div class="row">
			<!-- Left Column: List View -->
			<div class="col-lg-8 pe-lg-4">

				<?php if (is_home() && !is_front_page()): ?>
					<header class="mb-5">
						<h1 class="page-title h2 fw-bold border-bottom pb-2"><?php single_post_title(); ?></h1>
					</header>
				<?php else: ?>
					<h1 class="h4 fw-bold mb-4 border-bottom pb-2">Latest News</h1>
				<?php endif; ?>

				<div class="list-view-container">
					<?php
					if (have_posts()):
						/* Start the Loop */
						while (have_posts()):
							the_post();
							?>
							<article id="post-<?php the_ID(); ?>" <?php post_class('list-view-post'); ?>>

								<?php if (has_post_thumbnail()): ?>
									<a href="<?php the_permalink(); ?>" class="list-view-thumb-link">
										<img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>"
											alt="<?php the_title_attribute(); ?>" loading="lazy">
									</a>
								<?php else: ?>
									<div class="list-view-thumb-link bg-light d-flex align-items-center justify-content-center text-muted">
										<i class="fas fa-image fa-2x"></i>
									</div>
								<?php endif; ?>

								<div class="list-view-content">
									<div class="post-meta small text-muted mb-2">
										<span class="text-primary fw-bold me-2"><i class="fas fa-folder-open me-1"></i>
											<?php
											$categories = get_the_category();
											if (!empty($categories)) {
												echo esc_html($categories[0]->name);
											}
											?>
										</span>
										<span class="me-2">&bull;</span>
										<i class="far fa-calendar-alt me-1"></i> <?php echo bug_mohol_bangla_date(get_the_date()); ?>
										<span class="mx-2">&bull;</span>
										<i class="fas fa-user-edit me-1"></i> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" class="text-muted text-decoration-none"><?php the_author(); ?></a>
									</div>

									<h3 class="h4 fw-bold mb-2">
										<a href="<?php the_permalink(); ?>" class="post-title-link"><?php the_title(); ?></a>
									</h3>

									<div class="entry-summary text-muted mb-0 small line-clamp-2">
										<?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?>
									</div>
								</div>

							</article><!-- #post-<?php the_ID(); ?> -->
							<?php
						endwhile;

						bug_mohol_pagination();

					else:
						echo '<p>' . esc_html__('It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'bug-mohol') . '</p>';
						get_search_form();
					endif;
					?>
				</div>
			</div> <!-- .col-lg-8 -->

			<!-- Right Column: Sidebar -->
			<div class="col-lg-4 mt-5 mt-lg-0">
				<?php get_sidebar(); ?>
			</div> <!-- .col-lg-4 -->

		</div> <!-- .row -->

	</div> <!-- .container -->
</main><!-- #main -->

<?php
get_footer();
