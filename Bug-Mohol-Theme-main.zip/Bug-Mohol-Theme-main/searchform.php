<?php
/**
 * The template for displaying search forms in Bug Mohol
 *
 * @package Bug_Mohol
 */

?>
<form role="search" method="get" class="search-form w-100" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div class="input-group search-input-group shadow-sm rounded-pill overflow-hidden border">
        <input type="search" class="form-control border-0 px-4 py-2.5 shadow-none" placeholder="খুঁজুন..." value="<?php echo get_search_query(); ?>" name="s" required style="font-size: 15px;">
        <button class="btn btn-primary border-0 px-4" type="submit"><i class="fas fa-search me-1"></i> খুঁজুন</button>
    </div>
</form>
