<?php
/**
 * Bug Mohol functions and definitions
 *
 * @package Bug_Mohol
 */

if (!defined('_S_VERSION')) {
	define('_S_VERSION', '1.0.0');
}

function bug_mohol_setup()
{
	// Let WordPress manage the document title.
	add_theme_support('title-tag');

	// Enable support for Post Thumbnails on posts and pages.
	add_theme_support('post-thumbnails');

	// Define custom image sizes
	add_image_size('bug-mohol-hero-large', 800, 600, true);
	add_image_size('bug-mohol-hero-small', 400, 300, true);
	add_image_size('bug-mohol-list-thumb', 250, 180, true);
	add_image_size('bug-mohol-sidebar-thumb', 80, 80, true);

	// Switch default core markup to valid HTML5.
	add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

	// Add support for core custom logo.
	add_theme_support('custom-logo', array(
		'height' => 90,
		'width' => 300,
		'flex-width' => true,
		'flex-height' => true,
	));

	// Register Navigation Menus
	register_nav_menus(array(
		'primary'       => esc_html__('Primary Menu', 'bug-mohol'),
		'footer'        => esc_html__('Footer Menu', 'bug-mohol'),
	));
}
add_action('after_setup_theme', 'bug_mohol_setup');

/**
 * Register widget area.
 */
function bug_mohol_widgets_init()
{
	register_sidebar(array(
		'name' => esc_html__('Sidebar', 'bug-mohol'),
		'id' => 'sidebar-1',
		'description' => esc_html__('Add widgets here.', 'bug-mohol'),
		'before_widget' => '<section id="%1$s" class="widget %2$s mb-5">',
		'after_widget' => '</section>',
		'before_title' => '<h2 class="widget-title h5 border-bottom pb-2 mb-3">',
		'after_title' => '</h2>',
	));
    
    // Footer Widget Area 1
    register_sidebar(array(
        'name'          => esc_html__( 'Footer Widget Area 1', 'bug-mohol' ),
        'id'            => 'footer-1',
        'description'   => esc_html__( 'Add widgets here for the first footer column.', 'bug-mohol' ),
        'before_widget' => '<div id="%1$s" class="widget text-dark footer-widget %2$s mb-4 pb-2">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title footer-widget-title h5 fw-bold mb-4 text-dark position-relative pb-2">',
        'after_title'   => '</h3>',
    ));

    // Footer Widget Area 2
    register_sidebar(array(
        'name'          => esc_html__( 'Footer Widget Area 2', 'bug-mohol' ),
        'id'            => 'footer-2',
        'description'   => esc_html__( 'Add widgets here for the second footer column.', 'bug-mohol' ),
        'before_widget' => '<div id="%1$s" class="widget text-dark footer-widget %2$s mb-4 pb-2">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title footer-widget-title h5 fw-bold mb-4 text-dark position-relative pb-2">',
        'after_title'   => '</h3>',
    ));

    // Footer Widget Area 3
    register_sidebar(array(
        'name'          => esc_html__( 'Footer Widget Area 3', 'bug-mohol' ),
        'id'            => 'footer-3',
        'description'   => esc_html__( 'Add widgets here for the third footer column.', 'bug-mohol' ),
        'before_widget' => '<div id="%1$s" class="widget text-dark footer-widget %2$s mb-4 pb-2">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title footer-widget-title h5 fw-bold mb-4 text-dark position-relative pb-2">',
        'after_title'   => '</h3>',
    ));

    // Footer Widget Area 4 (Bottom Left)
    register_sidebar(array(
        'name'          => esc_html__( 'Footer Widget Area 4 (Bottom Left)', 'bug-mohol' ),
        'id'            => 'footer-4',
        'description'   => esc_html__( 'Add widgets here for the bottom left section (e.g. Social Icons).', 'bug-mohol' ),
        'before_widget' => '<div id="%1$s" class="widget inline-widget %2$s d-inline-block">',
        'after_widget'  => '</div>',
        'before_title'  => '<span class="fw-bold text-dark small me-3">',
        'after_title'   => '</span>',
    ));

    // Footer Widget Area 5 (Bottom Right / Apps)
    register_sidebar(array(
        'name'          => esc_html__( 'Footer Widget Area 5 (Bottom Right)', 'bug-mohol' ),
        'id'            => 'footer-5',
        'description'   => esc_html__( 'Add widgets here for the bottom right section (e.g. App Links).', 'bug-mohol' ),
        'before_widget' => '<div id="%1$s" class="widget inline-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title sr-only visually-hidden">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'bug_mohol_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function bug_mohol_scripts()
{
	// Bootstrap 5 CSS via CDN
	wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), '5.3.2');

	// FontAwesome
	wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');

	// Google Fonts (Anek Bangla)
	wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Anek+Bangla:wght@300;400;500;600;700;800&display=swap', array(), null);

	// Theme Main Stylesheet
	wp_enqueue_style('bug-mohol-style', get_stylesheet_uri(), array(), filemtime(get_stylesheet_directory() . '/style.css'));

	// Bootstrap 5 JS via CDN
	wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array(), '5.3.2', true);

	// Theme Custom JS
	wp_enqueue_script('bug-mohol-custom', get_template_directory_uri() . '/js/custom.js', array(), filemtime(get_stylesheet_directory() . '/js/custom.js'), true);
}
add_action('wp_enqueue_scripts', 'bug_mohol_scripts');

/**
 * Preload Critical Fonts (Anek Bangla & FontAwesome) for PageSpeed
 */
function bug_mohol_preload_fonts() {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	echo '<link rel="preload" href="https://fonts.googleapis.com/css2?family=Anek+Bangla:wght@300;400;500;600;700;800&display=swap" as="style">' . "\n";
	echo '<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
	echo '<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
}
add_action('wp_head', 'bug_mohol_preload_fonts', 1);

/**
 * Defer JavaScript to prevent render-blocking (PageSpeed Fix)
 */
function bug_mohol_defer_scripts($tag, $handle, $src) {
	if (is_admin()) {
		return $tag;
	}
	$defer_scripts = array('bootstrap-js', 'bug-mohol-custom');
	if (in_array($handle, $defer_scripts)) {
		return str_replace(' src', ' defer="defer" src', $tag);
	}
	return $tag;
}
add_filter('script_loader_tag', 'bug_mohol_defer_scripts', 10, 3);

/**
 * Custom walker for Bootstrap 5 navbar
 */
class Bootstrap_5_WP_Nav_Walker extends Walker_Nav_Menu
{
    public function start_lvl(&$output, $depth = 0, $args = null)
    {
        $output .= '<ul class="dropdown-menu shadow-sm">';
    }

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $is_dropdown = ($depth > 0);
        
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $args_array = (array) $args;
        if ( isset( $args_array['walker'] ) && is_object( $args_array['walker'] ) && method_exists( $args_array['walker'], 'has_children' ) ) {
            $has_children = $args_array['walker']->has_children;
        } else {
            $has_children = false; 
            if ( in_array('menu-item-has-children', $classes) ) {
                $has_children = true;
            }
        }

        $output .= '<li class="' . ($is_dropdown ? '' : 'nav-item') . ($has_children ? ' dropdown' : '') . '">';

        $atts = array();
        $atts['title'] = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';
        $atts['rel'] = !empty($item->xfn) ? $item->xfn : '';
        $atts['href'] = !empty($item->url) ? $item->url : '';

        $atts['class'] = $is_dropdown ? 'dropdown-item' : 'nav-link';

        if ($has_children) {
            $atts['class'] .= ' dropdown-toggle';
            $atts['data-bs-toggle'] = 'dropdown';
            $atts['aria-expanded'] = 'false';
        }

        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $title = apply_filters('the_title', $item->title, $item->ID);

        $item_output = isset($args->before) ? $args->before : '';
        $item_output .= '<a' . $attributes . '>';
        $item_output .= (isset($args->link_before) ? $args->link_before : '') . $title . (isset($args->link_after) ? $args->link_after : '');
        $item_output .= '</a>';
        $item_output .= isset($args->after) ? $args->after : '';

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * Custom excerpt length
 */
function bug_mohol_custom_excerpt_length($length)
{
	return 25; // Change excerpt to 25 words
}
add_filter('excerpt_length', 'bug_mohol_custom_excerpt_length', 999);

/**
 * Custom "Read More" link
 */
function bug_mohol_excerpt_more($more)
{
	return '... <a class="read-more small text-primary fw-bold text-decoration-none" href="' . get_permalink(get_the_ID()) . '">Read More <i class="fas fa-angle-double-right"></i></a>';
}
add_filter('excerpt_more', 'bug_mohol_excerpt_more');

/**
 * Helper function to convert English dates to Bengali
 */
function bug_mohol_bangla_date($date_str) {
    $eng = array('1','2','3','4','5','6','7','8','9','0', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday');
    $bng = array('১','২','৩','৪','৫','৬','৭','৮','৯','০', 'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর', 'শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার');
    return str_replace($eng, $bng, $date_str);
}

/**
 * Helper function to convert English numbers to Bengali
 */
function bug_mohol_bangla_number($number) {
    $eng = array('1','2','3','4','5','6','7','8','9','0');
    $bng = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
    return str_replace($eng, $bng, $number);
}

/**
 * =========================================================================
 * Custom Premium Breadcrumbs SEO with BreadcrumbList JSON-LD Schema
 * =========================================================================
 */
function bug_mohol_breadcrumbs() {
    // Defer to active SEO plugins' breadcrumbs if available
    if ( function_exists( 'yoast_breadcrumb' ) ) {
        yoast_breadcrumb( '<nav aria-label="breadcrumb" class="mb-4 bg-light p-3 rounded shadow-sm"><ol class="breadcrumb m-0">', '</ol></nav>' );
        return;
    }
    
    global $post;
    
    $home_title = 'প্রচ্ছদ';
    $separator  = '<li class="breadcrumb-item-separator px-2 text-muted" style="font-size: 0.85rem;"><i class="fas fa-angle-right opacity-50"></i></li>';
    
    // Breadcrumb array for schema markup
    $crumbs = array();
    
    // Main HTML wrapper
    echo '<nav aria-label="breadcrumb" class="mb-4 bug-mohol-breadcrumb-wrapper bg-light py-2 px-3 rounded border shadow-sm">';
    echo '<ol class="breadcrumb align-items-center m-0 p-0" style="font-size: 0.95rem; font-weight: 500; list-style: none; display: flex; flex-wrap: wrap;">';
    
    // Home Link
    echo '<li class="breadcrumb-item"><a href="' . esc_url( home_url( '/' ) ) . '" class="text-secondary text-decoration-none hover-primary"><i class="fas fa-home me-1"></i>' . esc_html( $home_title ) . '</a></li>';
    $crumbs[] = array(
        'name' => $home_title,
        'url'  => home_url( '/' )
    );
    
    if ( is_single() ) {
        echo $separator;
        $category = get_the_category();
        if ( !empty($category) ) {
            $cat = $category[0];
            echo '<li class="breadcrumb-item"><a href="' . esc_url( get_category_link( $cat->term_id ) ) . '" class="text-secondary text-decoration-none hover-primary">' . esc_html( $cat->name ) . '</a></li>';
            $crumbs[] = array(
                'name' => $cat->name,
                'url'  => get_category_link( $cat->term_id )
            );
        }
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark text-truncate d-inline-block" style="max-width: 300px;" aria-current="page">' . esc_html( get_the_title() ) . '</li>';
        $crumbs[] = array(
            'name' => get_the_title(),
            'url'  => get_permalink()
        );
    } elseif ( is_page() ) {
        if ( $post->post_parent ) {
            $parent_id  = $post->post_parent;
            $breadcrumbs = array();
            while ( $parent_id ) {
                $page = get_post( $parent_id );
                $breadcrumbs[] = array(
                    'name' => get_the_title( $page->ID ),
                    'url'  => get_permalink( $page->ID )
                );
                $parent_id  = $page->post_parent;
            }
            $breadcrumbs = array_reverse( $breadcrumbs );
            foreach ( $breadcrumbs as $crumb ) {
                echo $separator;
                echo '<li class="breadcrumb-item"><a href="' . esc_url( $crumb['url'] ) . '" class="text-secondary text-decoration-none hover-primary">' . esc_html( $crumb['name'] ) . '</a></li>';
                $crumbs[] = $crumb;
            }
        }
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( get_the_title() ) . '</li>';
        $crumbs[] = array(
            'name' => get_the_title(),
            'url'  => get_permalink()
        );
    } elseif ( is_category() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( single_cat_title( '', false ) ) . '</li>';
        $crumbs[] = array(
            'name' => single_cat_title( '', false ),
            'url'  => get_category_link( get_queried_object_id() )
        );
    } elseif ( is_tag() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( single_tag_title( '', false ) ) . '</li>';
        $crumbs[] = array(
            'name' => single_tag_title( '', false ),
            'url'  => get_tag_link( get_queried_object_id() )
        );
    } elseif ( is_day() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( get_the_time( 'j F, Y' ) ) . '</li>';
        $crumbs[] = array(
            'name' => get_the_time( 'j F, Y' ),
            'url'  => get_day_link( get_the_time( 'Y' ), get_the_time( 'm' ), get_the_time( 'd' ) )
        );
    } elseif ( is_month() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( get_the_time( 'F, Y' ) ) . '</li>';
        $crumbs[] = array(
            'name' => get_the_time( 'F, Y' ),
            'url'  => get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) )
        );
    } elseif ( is_year() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( get_the_time( 'Y' ) ) . '</li>';
        $crumbs[] = array(
            'name' => get_the_time( 'Y' ),
            'url'  => get_year_link( get_the_time( 'Y' ) )
        );
    } elseif ( is_author() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">' . esc_html( get_the_author() ) . '</li>';
        $crumbs[] = array(
            'name' => get_the_author(),
            'url'  => get_author_posts_url( get_the_author_meta( 'ID' ) )
        );
    } elseif ( is_search() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">অনুসন্ধান ফলাফল: "' . esc_html( get_search_query() ) . '"</li>';
        $crumbs[] = array(
            'name' => 'অনুসন্ধান ফলাফল: "' . get_search_query() . '"',
            'url'  => get_search_link()
        );
    } elseif ( is_404() ) {
        echo $separator;
        echo '<li class="breadcrumb-item active text-dark" aria-current="page">পেজ পাওয়া যায়নি (৪০৪)</li>';
        $crumbs[] = array(
            'name' => 'পেজ পাওয়া যায়নি (৪০৪)',
            'url'  => ''
        );
    }
    
    echo '</ol>';
    echo '</nav>';
    
    // Output BreadcrumbList JSON-LD Schema
    if ( !empty($crumbs) ) {
        $itemListElement = array();
        $position = 1;
        foreach ( $crumbs as $crumb ) {
            $item = array(
                '@type' => 'ListItem',
                'position' => $position,
                'name' => esc_attr( $crumb['name'] )
            );
            if ( !empty($crumb['url']) ) {
                $item['item'] = esc_url( $crumb['url'] );
            }
            $itemListElement[] = $item;
            $position++;
        }
        $breadcrumb_schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $itemListElement
        );
        echo '<script type="application/ld+json">' . json_encode( $breadcrumb_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
}

/**
 * =========================================================================
 * Custom Virtual Robots.txt Enhancements
 * =========================================================================
 */
function bug_mohol_custom_robots_txt( $output, $public ) {
    if ( '0' == $public ) {
        return $output;
    }
    $sitemap_url = esc_url( home_url( '/sitemap.xml' ) );
    $new_rules = "\n";
    $new_rules .= "User-agent: *\n";
    $new_rules .= "Disallow: /wp-admin/\n";
    $new_rules .= "Allow: /wp-admin/admin-ajax.php\n";
    $new_rules .= "Disallow: /wp-includes/\n";
    $new_rules .= "Disallow: /wp-content/plugins/\n";
    $new_rules .= "Disallow: /wp-content/themes/\n";
    $new_rules .= "Disallow: /trackback/\n";
    $new_rules .= "Disallow: /feed/\n";
    $new_rules .= "Disallow: /comments/feed/\n";
    $new_rules .= "Disallow: /*?*\n"; // Disallow URL parameters to avoid indexing duplicate pages
    $new_rules .= "Disallow: /*?\n";
    $new_rules .= "Allow: /wp-content/uploads/\n";
    $new_rules .= "Sitemap: {$sitemap_url}\n";
    return $output . $new_rules;
}
add_filter( 'robots_txt', 'bug_mohol_custom_robots_txt', 10, 2 );

/**
 * =========================================================================
 * Custom Built-in SEO Framework for Bug Mohol
 * =========================================================================
 * Generates comprehensive meta tags, OpenGraph, Twitter cards, and JSON-LD schema.
 * Automatically defers to active premium SEO plugins to prevent duplicate tags.
 */
function bug_mohol_custom_seo() {
    // Defer to active SEO plugins to prevent duplicate tags (Best Practice)
    if ( class_exists( 'WPSEO_Options' ) || // Yoast SEO
         defined( 'RANK_MATH_VERSION' ) ||  // Rank Math
         class_exists( 'All_in_One_SEO_Pack' ) || // All in One SEO
         class_exists( 'SEOPress' ) || // SEOPress
         class_exists( 'SquirrlySeo' ) // Squirrly
    ) {
        return;
    }

    global $post;
    
    // Default site info
    $site_name = get_bloginfo('name');
    $site_desc = get_bloginfo('description');
    $url = (is_ssl() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    
    // Meta Description & Title vars
    $meta_desc = $site_desc;
    $meta_img = '';
    $post_title = $site_name;

    if (is_singular()) {
        $post_title = get_the_title() . ' - ' . $site_name;
        
        // Extract a clean excerpt for description
        if (has_excerpt()) {
            $meta_desc = strip_tags(get_the_excerpt());
        } elseif (!empty($post->post_content)) {
            $meta_desc = wp_trim_words(strip_shortcodes(strip_tags($post->post_content)), 30, '...');
        }
        
        // Get featured image for Open Graph sharing
        if (has_post_thumbnail($post->ID)) {
            $img_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large');
            if ($img_src) {
                $meta_img = $img_src[0];
            }
        }
    } elseif (is_category()) {
        $post_title = single_cat_title('', false) . ' - ' . $site_name;
        $meta_desc = strip_tags(category_description());
    } elseif (is_tag()) {
        $post_title = single_tag_title('', false) . ' - ' . $site_name;
        $meta_desc = strip_tags(tag_description());
    } elseif (is_archive()) {
        $post_title = get_the_archive_title() . ' - ' . $site_name;
    }
    
    // Strip empty lines and enforce raw strings for meta
    $meta_desc = trim(str_replace(array("\r", "\n"), '', $meta_desc));
    if (empty($meta_desc)) {
        $meta_desc = $site_desc;
    }

    // Default image fallback if none found
    if (empty($meta_img)) {
        $meta_img = 'https://placehold.co/1200x630/0d6efd/ffffff?text=' . urlencode(get_bloginfo('name')); 
    }

    echo "\n<!-- Bug Mohol Custom SEO Start -->\n";
    
    // 1. Robots Directives (Prevent thin/duplicate indexing of searches and 404s)
    if ( is_search() || is_404() ) {
        echo '<meta name="robots" content="noindex, nofollow" />' . "\n";
    } else {
        echo '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />' . "\n";
    }

    // 2. Canonical URL
    echo '<link rel="canonical" href="' . esc_url($url) . '" />' . "\n";
    
    // 3. Standard Meta Tags
    echo '<meta name="description" content="' . esc_attr($meta_desc) . '" />' . "\n";

    $keywords = 'News, Newspaper, Theme, WordPress';
    if (is_singular()) {
        $tags = get_the_tags($post->ID);
        if ($tags) {
            $tag_names = array();
            foreach ($tags as $tag) {
                $tag_names[] = $tag->name;
            }
            $keywords = implode(', ', $tag_names);
        }
    }
    echo '<meta name="keywords" content="' . esc_attr($keywords) . '" />' . "\n";
    
    // 4. Open Graph (Facebook / LinkedIn)
    echo '<meta property="og:locale" content="' . get_locale() . '" />' . "\n";
    echo '<meta property="og:type" content="' . (is_single() ? 'article' : 'website') . '" />' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($post_title) . '" />' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($meta_desc) . '" />' . "\n";
    echo '<meta property="og:url" content="' . esc_url($url) . '" />' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '" />' . "\n";
    if (!empty($meta_img)) {
        echo '<meta property="og:image" content="' . esc_url($meta_img) . '" />' . "\n";
        echo '<meta property="og:image:width" content="1200" />' . "\n";
        echo '<meta property="og:image:height" content="630" />' . "\n";
    }

    if ( is_single() ) {
        echo '<meta property="article:published_time" content="' . esc_attr( get_the_date('c') ) . '" />' . "\n";
        echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date('c') ) . '" />' . "\n";
        
        $categories = get_the_category();
        if ( !empty($categories) ) {
            echo '<meta property="article:section" content="' . esc_attr( $categories[0]->name ) . '" />' . "\n";
        }
        
        $tags = get_the_tags();
        if ( $tags ) {
            foreach ( $tags as $tag ) {
                echo '<meta property="article:tag" content="' . esc_attr( $tag->name ) . '" />' . "\n";
            }
        }
    }
    
    // 5. Twitter Card Data
    echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
    echo '<meta name="twitter:title" content="' . esc_attr($post_title) . '" />' . "\n";
    echo '<meta name="twitter:description" content="' . esc_attr($meta_desc) . '" />' . "\n";
    if (!empty($meta_img)) {
        echo '<meta name="twitter:image" content="' . esc_url($meta_img) . '" />' . "\n";
    }

    // 6. Inline Dynamic JSON-LD Schema Markup
    $schema = array();
    
    // Logo detection
    $logo_url = '';
    if ( has_custom_logo() ) {
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $logo_data = wp_get_attachment_image_src( $custom_logo_id , 'full' );
        if ( $logo_data ) {
            $logo_url = $logo_data[0];
        }
    }
    
    // Social array for sameAs Organization links
    $social_profiles = array();
    $social_networks = array('facebook', 'twitter', 'linkedin', 'youtube', 'instagram', 'whatsapp');
    foreach ($social_networks as $key) {
        $s_url = get_theme_mod("bug_mohol_{$key}_url", '#');
        if (!empty($s_url) && $s_url !== '#') {
            $social_profiles[] = esc_url($s_url);
        }
    }

    if ( is_front_page() || is_home() ) {
        // WebSite Schema
        $website_schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'WebSite',
            '@id'      => esc_url( home_url( '/#website' ) ),
            'url'      => esc_url( home_url( '/' ) ),
            'name'     => esc_attr( $site_name ),
            'description' => esc_attr( $site_desc ),
            'potentialAction' => array(
                '@type'       => 'SearchAction',
                'target'      => esc_url( home_url( '/?s={search_term_string}' ) ),
                'query-input' => 'required name=search_term_string'
            )
        );
        $schema[] = $website_schema;

        // Organization Schema
        $org_schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            '@id'      => esc_url( home_url( '/#organization' ) ),
            'name'     => esc_attr( $site_name ),
            'url'      => esc_url( home_url( '/' ) ),
        );
        if ( !empty($logo_url) ) {
            $org_schema['logo'] = esc_url( $logo_url );
            $org_schema['image'] = esc_url( $logo_url );
        }
        if ( !empty($social_profiles) ) {
            $org_schema['sameAs'] = $social_profiles;
        }
        $schema[] = $org_schema;
    } elseif ( is_single() ) {
        // Article Schema
        $article_schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'NewsArticle',
            '@id'      => esc_url( $url . '#article' ),
            'isPartOf' => array(
                '@type' => 'WebPage',
                '@id'   => esc_url( $url ),
                'url'   => esc_url( $url ),
                'name'  => esc_attr( $post_title )
            ),
            'headline' => esc_attr( get_the_title() ),
            'description' => esc_attr( $meta_desc ),
            'datePublished' => get_the_date('c'),
            'dateModified' => get_the_modified_date('c'),
            'mainEntityOfPage' => esc_url( $url ),
            'author' => array(
                '@type' => 'Person',
                'name'  => esc_attr( get_the_author() ),
                'url'   => esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) )
            )
        );

        if ( !empty($meta_img) ) {
            $article_schema['image'] = esc_url( $meta_img );
        }

        // Publisher Organization inside Article
        $pub_schema = array(
            '@type' => 'Organization',
            'name'  => esc_attr( $site_name )
        );
        if ( !empty($logo_url) ) {
            $pub_schema['logo'] = array(
                '@type' => 'ImageObject',
                'url'   => esc_url( $logo_url )
            );
        }
        $article_schema['publisher'] = $pub_schema;

        $schema[] = $article_schema;
    } elseif ( is_page() ) {
        // WebPage Schema
        $page_schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'WebPage',
            '@id'      => esc_url( $url . '#webpage' ),
            'url'      => esc_url( $url ),
            'name'     => esc_attr( $post_title ),
            'description' => esc_attr( $meta_desc )
        );
        if ( !empty($meta_img) ) {
            $page_schema['image'] = esc_url( $meta_img );
        }
        $schema[] = $page_schema;
    }

    if ( !empty($schema) ) {
        foreach ( $schema as $s ) {
            echo '<script type="application/ld+json">' . json_encode( $s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>' . "\n";
        }
    }

    echo "<!-- Bug Mohol Custom SEO End -->\n\n";
}

// Hook SEO function into wp_head with high priority so it appears near the top
add_action('wp_head', 'bug_mohol_custom_seo', 5);

/**
 * =========================================================================
 * Custom Post Type: Web Stories
 * =========================================================================
 */
function bug_mohol_register_story_cpt() {
    $labels = array(
        'name'                  => _x( 'Stories', 'Post Type General Name', 'bug-mohol' ),
        'singular_name'         => _x( 'Story', 'Post Type Singular Name', 'bug-mohol' ),
        'menu_name'             => __( 'Stories', 'bug-mohol' ),
        'name_admin_bar'        => __( 'Story', 'bug-mohol' ),
        'archives'              => __( 'Story Archives', 'bug-mohol' ),
        'all_items'             => __( 'All Stories', 'bug-mohol' ),
        'add_new_item'          => __( 'Add New Story', 'bug-mohol' ),
        'add_new'               => __( 'Add New', 'bug-mohol' ),
        'edit_item'             => __( 'Edit Story', 'bug-mohol' ),
        'update_item'           => __( 'Update Story', 'bug-mohol' ),
        'view_item'             => __( 'View Story', 'bug-mohol' ),
        'search_items'          => __( 'Search Story', 'bug-mohol' ),
        'not_found'             => __( 'Not found', 'bug-mohol' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'bug-mohol' ),
        'featured_image'        => __( 'Poster Image (Portrait)', 'bug-mohol' ),
        'set_featured_image'    => __( 'Set poster image', 'bug-mohol' ),
        'remove_featured_image' => __( 'Remove poster image', 'bug-mohol' ),
        'use_featured_image'    => __( 'Use as poster image', 'bug-mohol' ),
    );
    $args = array(
        'label'                 => __( 'Story', 'bug-mohol' ),
        'description'           => __( 'Bug Mohol Stories', 'bug-mohol' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-media-document',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type( 'web-story', $args );
}
add_action( 'init', 'bug_mohol_register_story_cpt', 0 );


/**
 * =========================================================================
 * Custom Modular Pagination (Bengali Numbers & Bootstrap 5)
 * =========================================================================
 */
function bug_mohol_pagination() {
    $pagination = paginate_links( array(
        'mid_size'  => 2,
        'prev_text' => __( '<i class="fas fa-chevron-left me-1"></i> আগের খবর', 'bug-mohol' ),
        'next_text' => __( 'পরের খবর <i class="fas fa-chevron-right ms-1"></i>', 'bug-mohol' ),
        'type'      => 'array',
    ) );

    if ( is_array( $pagination ) ) {
        echo '<nav class="pagination-container mt-5 mb-5"><ul class="pagination justify-content-center m-0">';
        foreach ( $pagination as $page ) {
            // Translate numbers in pagination to Bengali
            $page = bug_mohol_bangla_number($page);
            // Replace default WordPress page-numbers class with Bootstrap page-link
            $page = str_replace( 'page-numbers', 'page-link border-0 shadow-sm mx-1 rounded', $page );
            
            // Check if active page (has 'current' class) and add active class to page-item
            $active_class = strpos($page, 'current') !== false ? ' active' : '';
            echo '<li class="page-item' . $active_class . '">' . $page . '</li>';
        }
        echo '</ul></nav>';
    }
}


/**
 * =========================================================================
 * Theme Customizer Settings
 * =========================================================================
 */
function bug_mohol_customize_register( $wp_customize ) {
    
    // SECTION 1: Hero Section Settings
    $wp_customize->add_section( 'bug_mohol_hero_section' , array(
        'title'      => esc_html__( 'Hero Section Settings', 'bug-mohol' ),
        'priority'   => 30,
    ) );
    
    $wp_customize->add_setting( 'hero_badge_text' , array(
        'default'   => 'সর্বশেষ',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field'
    ) );
    
    $wp_customize->add_control( 'hero_badge_text', array(
        'label'      => esc_html__( 'Live Badge Text', 'bug-mohol' ),
        'description'=> esc_html__( 'e.g. সর্বশেষ, সরাসরি. Leave entirely blank to hide the badge.', 'bug-mohol' ),
        'section'    => 'bug_mohol_hero_section',
        'settings'   => 'hero_badge_text',
        'type'       => 'text',
    ) );

    // SECTION 2: General & Header Settings
    $wp_customize->add_section( 'bug_mohol_general_settings' , array(
        'title'      => esc_html__( 'General & Header Settings', 'bug-mohol' ),
        'priority'   => 31,
    ) );

    $wp_customize->add_setting( 'bug_mohol_location' , array(
        'default'   => 'ঢাকা',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field'
    ) );
    
    $wp_customize->add_control( 'bug_mohol_location', array(
        'label'      => esc_html__( 'Location (Top Bar)', 'bug-mohol' ),
        'section'    => 'bug_mohol_general_settings',
        'type'       => 'text',
    ) );


    // SECTION 3: Social Links Customization
    $wp_customize->add_section( 'bug_mohol_social_section' , array(
        'title'      => esc_html__( 'Social Media Links', 'bug-mohol' ),
        'priority'   => 32,
    ) );

    $socials = array(
        'facebook'  => 'Facebook URL',
        'twitter'   => 'Twitter / X URL',
        'linkedin'  => 'LinkedIn URL',
        'youtube'   => 'YouTube URL',
        'instagram' => 'Instagram URL',
        'whatsapp'  => 'WhatsApp URL',
    );

    foreach ( $socials as $key => $label ) {
        $wp_customize->add_setting( "bug_mohol_{$key}_url" , array(
            'default'   => '#',
            'transport' => 'refresh',
            'sanitize_callback' => 'esc_url_raw'
        ) );
        
        $wp_customize->add_control( "bug_mohol_{$key}_url", array(
            'label'      => esc_html__( $label, 'bug-mohol' ),
            'section'    => 'bug_mohol_social_section',
            'type'       => 'url',
        ) );
    }

    // SECTION 4: Footer Editorial Info Customization
    $wp_customize->add_section( 'bug_mohol_footer_editor_section' , array(
        'title'      => esc_html__( 'Footer: Editorial Info', 'bug-mohol' ),
        'priority'   => 33,
    ) );

    $editorial_fields = array(
        'editor'        => array( 'Label' => 'Editor Name', 'Default' => 'তৌফিক জামান তপু' ),
        'publisher'     => array( 'Label' => 'Publisher Name', 'Default' => 'তৌফিক জামান তপু' ),
        'press_info'    => array( 'Label' => 'Press and Print Address', 'Default' => 'বগড়া প্রেস ও প্রকাশনা ভবন, কারওয়ান বাজার, ঢাকা।' ),
        'office_addr'   => array( 'Label' => 'Office Address', 'Default' => '১২৩/এ, কারওয়ান বাজার, ঢাকা-১২১৫।' ),
    );

    foreach ( $editorial_fields as $key => $data ) {
        $wp_customize->add_setting( "bug_mohol_{$key}" , array(
            'default'   => $data['Default'],
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        
        $wp_customize->add_control( "bug_mohol_{$key}", array(
            'label'      => esc_html__( $data['Label'], 'bug-mohol' ),
            'section'    => 'bug_mohol_footer_editor_section',
            'type'       => 'text',
        ) );
    }

    // SECTION 5: Footer Contact Info Customization
    $wp_customize->add_section( 'bug_mohol_footer_contact_section' , array(
        'title'      => esc_html__( 'Footer: Contact & Ads', 'bug-mohol' ),
        'priority'   => 34,
    ) );

    $wp_customize->add_setting( 'bug_mohol_contact_email' , array(
        'default'   => 'info@bugmohol.com',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_email'
    ) );
    $wp_customize->add_control( 'bug_mohol_contact_email', array(
        'label'      => esc_html__( 'Contact Email', 'bug-mohol' ),
        'section'    => 'bug_mohol_footer_contact_section',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'bug_mohol_ads_phone' , array(
        'default'   => '+৮৮ ০১৯১১-১২৩৪৫৬',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field'
    ) );
    $wp_customize->add_control( 'bug_mohol_ads_phone', array(
        'label'      => esc_html__( 'Advertising Phone', 'bug-mohol' ),
        'section'    => 'bug_mohol_footer_contact_section',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'bug_mohol_ads_email' , array(
        'default'   => 'ads@bugmohol.com',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_email'
    ) );
    $wp_customize->add_control( 'bug_mohol_ads_email', array(
        'label'      => esc_html__( 'Advertising Email', 'bug-mohol' ),
        'section'    => 'bug_mohol_footer_contact_section',
        'type'       => 'text',
    ) );
    
    // SECTION 6: Stories Section Settings
    $wp_customize->add_section( 'bug_mohol_stories_section' , array(
        'title'      => esc_html__( 'Stories Settings', 'bug-mohol' ),
        'priority'   => 35,
    ) );

    $wp_customize->add_setting( 'bug_mohol_stories_title' , array(
        'default'   => 'স্টোরি',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field'
    ) );
    $wp_customize->add_control( 'bug_mohol_stories_title', array(
        'label'      => esc_html__( 'Stories Heading', 'bug-mohol' ),
        'section'    => 'bug_mohol_stories_section',
        'type'       => 'text',
    ) );

    // SECTION 7: AdSense & Monetization Settings
    $wp_customize->add_section( 'bug_mohol_adsense_section' , array(
        'title'      => esc_html__( 'AdSense & Monetization Settings', 'bug-mohol' ),
        'priority'   => 36,
    ) );

    // Lazyload Toggle Setting
    $wp_customize->add_setting( 'bug_mohol_lazyload_enable' , array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean'
    ) );
    $wp_customize->add_control( 'bug_mohol_lazyload_enable', array(
        'label'      => esc_html__( 'Enable Native Image Lazy Loading', 'bug-mohol' ),
        'description'=> esc_html__( 'Adds loading="lazy" attribute automatically to content and thumbnail elements for faster speeds.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'checkbox',
    ) );

    // Global Ads Toggle Setting
    $wp_customize->add_setting( 'bug_mohol_ads_enable' , array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean'
    ) );
    $wp_customize->add_control( 'bug_mohol_ads_enable', array(
        'label'      => esc_html__( 'Enable Advertising / Ads', 'bug-mohol' ),
        'description'=> esc_html__( 'Toggle all advertisement slots (both codes and placeholders) on/off globally across the site.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'checkbox',
    ) );

    // Ad Placeholders Toggle Setting
    $wp_customize->add_setting( 'bug_mohol_ad_placeholders_enable' , array(
        'default'   => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'wp_validate_boolean'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_placeholders_enable', array(
        'label'      => esc_html__( 'Enable Ad Visual Placeholders', 'bug-mohol' ),
        'description'=> esc_html__( 'Show dashed glassmorphic placeholders ("বিজ্ঞাপন দিন") when ad slots are empty. Uncheck to hide empty ad slots completely.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'checkbox',
    ) );

    // Header Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_header' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_header', array(
        'label'      => esc_html__( 'Header Leaderboard Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste your AdSense / HTML code here. Best size: 728x90 or responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Post Top Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_post_top' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_post_top', array(
        'label'      => esc_html__( 'Single Post Top Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code to show above the post article content. Best size: responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Post Bottom Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_post_bottom' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_post_bottom', array(
        'label'      => esc_html__( 'Single Post Bottom Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code to show below the post article content. Best size: responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Sidebar Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_sidebar' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_sidebar', array(
        'label'      => esc_html__( 'Sidebar Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code to show inside the sidebar. Best size: 300x250 or responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Homepage Top Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_home_top' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_home_top', array(
        'label'      => esc_html__( 'Homepage Top Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code to show at the top of the homepage (first page only). Best size: 728x90 or responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Homepage Middle Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_home_middle' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_home_middle', array(
        'label'      => esc_html__( 'Homepage Middle Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code to show in the middle of the homepage (below Sports block). Best size: 728x90 or responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Homepage Bottom Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_home_bottom' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_home_bottom', array(
        'label'      => esc_html__( 'Homepage Bottom Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code to show at the bottom of the homepage (above footer). Best size: 728x90 or responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // Sticky Anchor Footer Ad slot setting
    $wp_customize->add_setting( 'bug_mohol_ad_anchor' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'bug_mohol_sanitize_ad_code'
    ) );
    $wp_customize->add_control( 'bug_mohol_ad_anchor', array(
        'label'      => esc_html__( 'Sticky Footer Anchor Ad Code', 'bug-mohol' ),
        'description'=> esc_html__( 'Paste ad code for a floating sticky ad at the bottom of all pages. Best size: 320x50, 728x90 or responsive.', 'bug-mohol' ),
        'section'    => 'bug_mohol_adsense_section',
        'type'       => 'textarea',
    ) );

    // SECTION 8: Homepage Categories Settings
    $wp_customize->add_section( 'bug_mohol_homepage_cats_section' , array(
        'title'      => esc_html__( 'Homepage Category Blocks', 'bug-mohol' ),
        'priority'   => 37,
    ) );

    // Fetch dynamic categories
    $categories = get_categories( array( 'hide_empty' => false ) );
    $cat_choices = array( '' => '— Standard / Default —' );
    if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
        foreach ( $categories as $category ) {
            $cat_choices[$category->slug] = $category->name . ' (' . $category->slug . ')';
        }
    }

    $homepage_cats = array(
        'homepage_category_selected'  => array( 'Label' => 'Selected Section (নির্বাচিত)', 'Default' => 'নির্বাচিত' ),
        'homepage_category_national'  => array( 'Label' => 'National Section (জাতীয়)', 'Default' => 'national' ),
        'homepage_category_world'     => array( 'Label' => 'World Section (বিশ্ব)', 'Default' => 'international' ),
        'homepage_category_sports'    => array( 'Label' => 'Sports Section (খেলা)', 'Default' => 'sports' ),
        'homepage_category_jobs'      => array( 'Label' => 'Jobs Section (চাকরি)', 'Default' => 'jobs' ),
        'homepage_category_health'    => array( 'Label' => 'Health Section (স্বাস্থ্যকথা)', 'Default' => 'health' ),
        'homepage_category_lifestyle' => array( 'Label' => 'Lifestyle Section (ডাক্তারবাড়ি)', 'Default' => 'lifestyle' ),
    );

    foreach ( $homepage_cats as $key => $data ) {
        $wp_customize->add_setting( $key , array(
            'default'   => $data['Default'],
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        
        $wp_customize->add_control( $key, array(
            'label'       => esc_html__( $data['Label'], 'bug-mohol' ),
            'section'     => 'bug_mohol_homepage_cats_section',
            'type'        => 'select',
            'choices'     => $cat_choices,
        ) );
    }

    // SECTION 6: SEO & Metadata Settings
    $wp_customize->add_section( 'bug_mohol_seo_settings' , array(
        'title'      => esc_html__( 'SEO & Metadata Settings', 'bug-mohol' ),
        'priority'   => 36,
    ) );

    // 1. Home Title
    $wp_customize->add_setting( 'bug_mohol_seo_home_title' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field'
    ) );
    $wp_customize->add_control( 'bug_mohol_seo_home_title', array(
        'label'       => esc_html__( 'Custom Homepage Meta Title', 'bug-mohol' ),
        'description' => esc_html__( 'Leave empty to fall back to the site title and tagline.', 'bug-mohol' ),
        'section'     => 'bug_mohol_seo_settings',
        'type'        => 'text',
    ) );

    // 2. Home Meta Description
    $wp_customize->add_setting( 'bug_mohol_seo_home_desc' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_textarea_field'
    ) );
    $wp_customize->add_control( 'bug_mohol_seo_home_desc', array(
        'label'       => esc_html__( 'Custom Homepage Meta Description', 'bug-mohol' ),
        'description' => esc_html__( 'Recommended under 160 characters.', 'bug-mohol' ),
        'section'     => 'bug_mohol_seo_settings',
        'type'        => 'textarea',
    ) );

    // 3. Default OG Image
    $wp_customize->add_setting( 'bug_mohol_seo_default_image' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw'
    ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'bug_mohol_seo_default_image', array(
        'label'       => esc_html__( 'Default Open Graph Fallback Image', 'bug-mohol' ),
        'description' => esc_html__( 'Uploaded image will display as a link preview on Facebook/Discord/Twitter when no featured image is found.', 'bug-mohol' ),
        'section'     => 'bug_mohol_seo_settings',
    ) ) );

    // 4. Global Noindex Checkbox
    $wp_customize->add_setting( 'bug_mohol_seo_global_noindex' , array(
        'default'   => false,
        'transport' => 'refresh',
        'sanitize_callback' => 'absint'
    ) );
    $wp_customize->add_control( 'bug_mohol_seo_global_noindex', array(
        'label'       => esc_html__( 'Enable Global NOINDEX (Hide Site from Search)', 'bug-mohol' ),
        'description' => esc_html__( 'Checks the noindex box globally. Useful for staging/private environments.', 'bug-mohol' ),
        'section'     => 'bug_mohol_seo_settings',
        'type'        => 'checkbox',
    ) );

    // 5. Sitemap URL
    $wp_customize->add_setting( 'bug_mohol_seo_sitemap_url' , array(
        'default'   => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw'
    ) );
    $wp_customize->add_control( 'bug_mohol_seo_sitemap_url', array(
        'label'       => esc_html__( 'Custom Sitemap URL', 'bug-mohol' ),
        'description' => esc_html__( 'Specify the location of your sitemap file (e.g. /sitemap.xml). Leave empty to use /wp-sitemap.xml.', 'bug-mohol' ),
        'section'     => 'bug_mohol_seo_settings',
        'type'        => 'text',
    ) );
}
add_action( 'customize_register', 'bug_mohol_customize_register' );

/**
 * Pass-through sanitization callback for raw AdSense script tags
 */
function bug_mohol_sanitize_ad_code( $input ) {
    return $input;
}

/**
 * Helper function to render a customizer-driven AdSense slot or elegant visual placeholder fallback
 */
function bug_mohol_render_ad_slot( $slot_id, $placeholder_title = 'Advertisement', $dimensions = '728 x 90' ) {
    // Return early if ads are disabled globally
    if ( !get_theme_mod( 'bug_mohol_ads_enable', true ) ) {
        return;
    }

    $ad_code = get_theme_mod( $slot_id, '' );

    if ( $dimensions === 'anchor' ) {
        // Sticky Footer Anchor Ad layout
        if ( !empty( $ad_code ) ) {
            echo '
            <div class="bug-mohol-sticky-anchor-wrapper position-fixed bottom-0 start-50 translate-middle-x pb-1" style="z-index: 9999; width: 100%; max-width: 728px; text-align: center;">
                <div class="position-relative d-inline-block bg-white shadow-lg border rounded-top overflow-hidden" style="min-width: 320px; min-height: 50px;">
                    <button onclick="this.parentElement.parentElement.remove()" class="position-absolute top-0 end-0 bg-dark text-white rounded-circle border-0 d-flex align-items-center justify-content-center hover-scale" style="width: 22px; height: 22px; font-size: 10px; transform: translate(30%, -30%); z-index: 10000; cursor: pointer; font-weight: bold; box-shadow: 0 2px 6px rgba(0,0,0,0.3);" title="বিজ্ঞাপন বন্ধ করুন">✕</button>
                    <div style="padding: 5px 0;">' . $ad_code . '</div>
                </div>
            </div>';
        } else {
            if ( !get_theme_mod( 'bug_mohol_ad_placeholders_enable', true ) ) {
                return;
            }
            echo '
            <div class="bug-mohol-sticky-anchor-wrapper position-fixed bottom-0 start-50 translate-middle-x pb-1" style="z-index: 9999; width: 100%; max-width: 728px; text-align: center;">
                <div class="position-relative d-inline-block bg-white shadow-lg border rounded-top overflow-hidden p-2" style="min-width: 320px; border-color: rgba(37, 99, 235, 0.2) !important; background: rgba(255,255,255,0.95); backdrop-filter: blur(10px);">
                    <button onclick="this.parentElement.parentElement.remove()" class="position-absolute top-0 end-0 bg-dark text-white rounded-circle border-0 d-flex align-items-center justify-content-center" style="width: 22px; height: 22px; font-size: 10px; transform: translate(30%, -30%); z-index: 10000; cursor: pointer; font-weight: bold; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">✕</button>
                    <div class="d-flex align-items-center justify-content-center gap-2 small text-muted px-3">
                        <span class="ad-label-pill bg-light border text-uppercase fw-bold text-primary px-2 py-0.5 rounded-pill" style="font-size: 0.65rem; letter-spacing: 0.5px;">
                            <i class="fas fa-ad"></i> বিজ্ঞাপন
                        </span>
                        <span class="fw-semibold text-secondary" style="font-size: 0.78rem;">' . esc_html( $placeholder_title ) . '</span>
                    </div>
                </div>
            </div>';
        }
        return;
    }

    if ( !empty( $ad_code ) ) {
        echo '<div class="bug-mohol-ad-wrapper text-center my-4 overflow-hidden">' . $ad_code . '</div>';
    } else {
        // Return silently if placeholders are disabled
        if ( !get_theme_mod( 'bug_mohol_ad_placeholders_enable', true ) ) {
            return;
        }
        
        // Render a beautiful, glassmorphic visual placeholder that matches professional layouts
        $max_width = '';
        $height = '';
        if ( strpos( $dimensions, '728' ) !== false ) {
            $max_width = 'max-width: 728px;';
            $height = 'height: 90px;';
        } elseif ( strpos( $dimensions, '300' ) !== false ) {
            $max_width = 'max-width: 300px;';
            $height = 'height: 250px;';
        } else {
            $max_width = 'max-width: 100%;';
            $height = 'min-height: 100px;';
        }
        
        echo '
        <div class="bug-mohol-ad-wrapper text-center my-4">
            <div class="ad-placeholder-premium d-inline-flex flex-column align-items-center justify-content-center text-muted shadow-sm w-100" 
                 style="' . $max_width . ' ' . $height . ' border: 2px dashed rgba(37, 99, 235, 0.25); border-radius: 12px; background: rgba(37, 99, 235, 0.02); padding: 15px; position: relative; overflow: hidden; transition: all 0.3s ease;">
                <div class="ad-label-pill bg-light border text-uppercase fw-bold text-primary px-3 py-1 rounded-pill mb-1" style="font-size: 0.72rem; letter-spacing: 1px; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">
                    <i class="fas fa-ad me-1"></i> বিজ্ঞাপন
                </div>
                <span class="small fw-semibold text-secondary" style="font-size: 0.85rem;">' . esc_html( $placeholder_title ) . ' (' . esc_html( $dimensions ) . ')</span>
                <style>
                    .ad-placeholder-premium:hover {
                        border-color: rgba(37, 99, 235, 0.5) !important;
                        background: rgba(37, 99, 235, 0.05) !important;
                        transform: translateY(-2px);
                        box-shadow: 0 8px 20px rgba(37, 99, 235, 0.06) !important;
                    }
                    body.dark-mode .ad-placeholder-premium {
                        background: rgba(96, 165, 250, 0.02) !important;
                        border-color: rgba(96, 165, 250, 0.2) !important;
                    }
                    body.dark-mode .ad-placeholder-premium:hover {
                        background: rgba(96, 165, 250, 0.04) !important;
                        border-color: rgba(96, 165, 250, 0.4) !important;
                    }
                    body.dark-mode .ad-label-pill {
                        background: #1e293b !important;
                        border-color: rgba(255,255,255,0.05) !important;
                        color: #60a5fa !important;
                    }
                </style>
            </div>
        </div>';
    }
}

/**
 * Dynamic In-Article related posts ("আরও পড়ুন" / Read More) injection.
 * Finds the middle paragraph of single posts and inserts a beautiful glassmorphic 2-column list of related posts.
 */
function bug_mohol_inject_in_article_readmore( $content ) {
    // Only target single post body content
    if ( ! is_single() || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    global $post;
    $categories = get_the_category( $post->ID );
    if ( ! $categories ) {
        return $content;
    }

    $category_ids = array();
    foreach ( $categories as $cat ) {
        $category_ids[] = $cat->term_id;
    }

    // Query 4 related posts from same category (excluding active post)
    $args = array(
        'category__in'        => $category_ids,
        'post__not_in'        => array( $post->ID ),
        'posts_per_page'      => 4,
        'ignore_sticky_posts' => true,
    );

    $related_query = new WP_Query( $args );

    if ( ! $related_query->have_posts() ) {
        return $content;
    }

    // Generate the premium glassmorphic Read More list HTML
    $readmore_html = '
    <div class="premium-in-article-readmore my-4 p-4 rounded-4 shadow-sm border">
        <div class="readmore-header d-flex align-items-center gap-2 mb-3 border-bottom pb-2">
            <span class="pulse-star-icon d-flex align-items-center justify-content-center bg-primary text-white rounded-circle animate-pulse" style="width: 24px; height: 24px;">
                <i class="fas fa-star" style="font-size: 10px;"></i>
            </span>
            <h4 class="h6 fw-bold mb-0 text-primary text-uppercase" style="letter-spacing: 0.5px; font-size: 0.95rem;">আরও পড়ুন</h4>
        </div>
        <ul class="premium-readmore-list list-unstyled mb-0 d-flex flex-column gap-3">';

    while ( $related_query->have_posts() ) {
        $related_query->the_post();
        
        $readmore_html .= '
        <li class="d-flex align-items-start gap-2 readmore-list-item">
            <i class="fas fa-chevron-right text-primary mt-1 flex-shrink-0" style="font-size: 0.85rem;"></i>
            <div class="readmore-list-body flex-grow-1">
                <h5 class="fw-bold mb-0" style="font-size: 1.05rem; line-height: 1.55;">
                    <a href="' . get_permalink() . '" class="text-dark text-decoration-none readmore-list-link transition-colors">' . get_the_title() . '</a>
                </h5>
            </div>
        </li>';
    }

    $readmore_html .= '
        </ul>
    </div>';

    wp_reset_postdata();

    // Split paragraphs inside the active article body and inject after the middle paragraph
    $paragraphs = explode( '</p>', $content );
    $count = count( $paragraphs );

    if ( $count > 2 ) {
        // Calculate middle index
        $middle_index = floor( $count / 2 ) - 1; // 0-indexed adjustment
        if ( $middle_index < 0 ) {
            $middle_index = 0;
        }
        
        $paragraphs[$middle_index] .= $readmore_html;
    } else {
        // Fallback for short posts: append right after the 1st paragraph
        $paragraphs[0] .= $readmore_html;
    }

    return implode( '</p>', $paragraphs );
}
add_filter( 'the_content', 'bug_mohol_inject_in_article_readmore' );

/**
 * SEO & Social Share Preview Meta Tags (Open Graph and Twitter Cards).
 * Injected in the page <head> dynamically.
 */
function bug_mohol_add_social_share_meta_tags() {
    if ( is_single() ) {
        global $post;
        setup_postdata( $post );
        
        $title       = esc_attr( get_the_title() );
        $url         = esc_url( get_permalink() );
        $description = esc_attr( wp_strip_all_tags( get_the_excerpt() ) );
        if ( empty( $description ) ) {
            $description = esc_attr( wp_strip_all_tags( wp_trim_words( $post->post_content, 30 ) ) );
        }
        
        $image = '';
        if ( has_post_thumbnail( $post->ID ) ) {
            $image = esc_url( get_the_post_thumbnail_url( $post->ID, 'full' ) );
        } else {
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            if ( $custom_logo_id ) {
                $image = esc_url( wp_get_attachment_image_url( $custom_logo_id, 'full' ) );
            }
        }
        
        echo "\n" . '<!-- Open Graph / Facebook Share Preview -->' . "\n";
        echo '<meta property="og:title" content="' . $title . '">' . "\n";
        echo '<meta property="og:type" content="article">' . "\n";
        echo '<meta property="og:url" content="' . $url . '">' . "\n";
        if ( !empty( $image ) ) {
            echo '<meta property="og:image" content="' . $image . '">' . "\n";
        }
        echo '<meta property="og:description" content="' . $description . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
        
        echo "\n" . '<!-- Twitter Card Preview -->' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . $title . '">' . "\n";
        echo '<meta name="twitter:description" content="' . $description . '">' . "\n";
        if ( !empty( $image ) ) {
            echo '<meta name="twitter:image" content="' . $image . '">' . "\n";
        }
        echo "\n";
        
        wp_reset_postdata();
    } else {
        $title       = esc_attr( get_bloginfo( 'name' ) );
        $url         = esc_url( home_url( '/' ) );
        $description = esc_attr( get_bloginfo( 'description' ) );
        
        $image = '';
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $image = esc_url( wp_get_attachment_image_url( $custom_logo_id, 'full' ) );
        }
        
        echo "\n" . '<!-- Open Graph / Facebook Share Preview -->' . "\n";
        echo '<meta property="og:title" content="' . $title . '">' . "\n";
        echo '<meta property="og:type" content="website">' . "\n";
        echo '<meta property="og:url" content="' . $url . '">' . "\n";
        if ( !empty( $image ) ) {
            echo '<meta property="og:image" content="' . $image . '">' . "\n";
        }
        echo '<meta property="og:description" content="' . $description . '">' . "\n";
        echo '<meta property="og:site_name" content="' . $title . '">' . "\n";
        
        echo "\n" . '<!-- Twitter Card Preview -->' . "\n";
        echo '<meta name="twitter:card" content="summary">' . "\n";
        echo '<meta name="twitter:title" content="' . $title . '">' . "\n";
        echo '<meta name="twitter:description" content="' . $description . '">' . "\n";
        if ( !empty( $image ) ) {
            echo '<meta name="twitter:image" content="' . $image . '">' . "\n";
        }
        echo "\n";
    }
}
add_action( 'wp_head', 'bug_mohol_add_social_share_meta_tags', 5 );

/**
 * SEO FAQ accordions with automatic JSON-LD Schema generation.
 * Usage:
 * [faq_section title="সচরাচর জিজ্ঞাস্য"]
 *   [faq_item question="প্রশ্ন ১"]উত্তর ১[/faq_item]
 *   [faq_item question="প্রশ্ন ২"]উত্তর ২[/faq_item]
 * [/faq_section]
 */
global $bug_mohol_faq_items;
$bug_mohol_faq_items = array();

function bug_mohol_faq_section_shortcode( $atts, $content = null ) {
    global $bug_mohol_faq_items;
    
    // Clear any previous FAQ item records to prevent bleeding
    $bug_mohol_faq_items = array();
    
    $atts = shortcode_atts( array(
        'title' => 'সচরাচর জিজ্ঞাস্য (FAQ)',
    ), $atts );
    
    // Parse nested [faq_item] codes
    $faq_content = do_shortcode( $content );
    
    // Build JSON-LD SEO Schema dynamically
    $schema_html = '';
    if ( !empty( $bug_mohol_faq_items ) ) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'mainEntity' => array()
        );
        foreach ( $bug_mohol_faq_items as $item ) {
            $schema['mainEntity'][] = array(
                '@type' => 'Question',
                'name' => $item['question'],
                'acceptedAnswer' => array(
                    '@type' => 'Answer',
                    'text' => $item['answer']
                )
            );
        }
        $schema_html = "\n" . '<!-- Auto-generated FAQ SEO JSON-LD Schema -->' . "\n";
        $schema_html .= '<script type="application/ld+json">' . json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>' . "\n";
    }
    
    return '
    <div class="bug-mohol-faq-block my-5 p-4 rounded-4 shadow-sm border bg-white">
        <h3 class="fw-bold mb-4 d-flex align-items-center gap-2 border-bottom pb-3 text-dark" style="font-size: 1.25rem;">
            <i class="fas fa-question-circle text-primary"></i> ' . esc_html( $atts['title'] ) . '
        </h3>
        <div class="accordion accordion-flush premium-faq-accordion" id="bugMoholFAQAccordion">
            ' . $faq_content . '
        </div>
    </div>
    ' . $schema_html;
}
add_shortcode( 'faq_section', 'bug_mohol_faq_section_shortcode' );

function bug_mohol_faq_item_shortcode( $atts, $content = null ) {
    global $bug_mohol_faq_items;
    
    $atts = shortcode_atts( array(
        'question' => '',
    ), $atts );
    
    $id = 'faq-' . md5( $atts['question'] );
    $answer = wp_strip_all_tags( $content );
    
    // Store in global array for parent section to output as JSON-LD schema
    $bug_mohol_faq_items[] = array(
        'question' => $atts['question'],
        'answer'   => $answer
    );
    
    return '
    <div class="accordion-item border-bottom py-2 bg-transparent">
        <h2 class="accordion-header" id="heading-' . $id . '">
            <button class="accordion-button collapsed fw-bold text-dark bg-transparent px-0 py-3 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-' . $id . '" aria-expanded="false" aria-controls="collapse-' . $id . '" style="font-size: 1.05rem;">
                ' . esc_html( $atts['question'] ) . '
            </button>
        </h2>
        <div id="collapse-' . $id . '" class="accordion-collapse collapse" aria-labelledby="heading-' . $id . '" data-bs-parent="#bugMoholFAQAccordion">
            <div class="accordion-body px-0 py-3 text-secondary" style="font-size: 0.98rem; line-height: 1.7;">
                ' . wpautop( esc_html( $content ) ) . '
            </div>
        </div>
    </div>
    ';
}
add_shortcode( 'faq_item', 'bug_mohol_faq_item_shortcode' );

/**
 * Render sticky footer anchor ad globally in wp_footer
 */
function bug_mohol_render_sticky_anchor_ad() {
    if ( function_exists( 'bug_mohol_render_ad_slot' ) ) {
        bug_mohol_render_ad_slot( 'bug_mohol_ad_anchor', 'স্টিকি এঙ্কর বিজ্ঞাপন (৩২০ x ৫০)', 'anchor' );
    }
}
add_action( 'wp_footer', 'bug_mohol_render_sticky_anchor_ad', 100 );

/**
 * Add Google Translate element for English <-> Bangla client switcher
 */
function bug_mohol_google_translate_script() {
    echo '
    <div id="google_translate_element" style="display:none; position:fixed; z-index:-1; opacity:0; pointer-events:none;"></div>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: "bn",
                includedLanguages: "en,bn",
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
                autoDisplay: false
            }, "google_translate_element");
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" async defer></script>
    ';
}
add_action( 'wp_footer', 'bug_mohol_google_translate_script', 99 );


/**
 * Elegant Custom Dynamic SEO, Schema, and Metadata Injection Suite
 */
function bug_mohol_seo_meta_tags() {
    global $post;
    
    // Core SEO parameters
    $title = '';
    $description = '';
    $image_url = get_theme_mod( 'bug_mohol_seo_default_image', '' );
    $url = esc_url( home_url( add_query_arg( array(), $GLOBALS['wp']->request ) ) );
    $site_name = get_bloginfo( 'name' );
    $type = 'website';
    $locale = ( isset( $_COOKIE['googtrans'] ) && strpos( $_COOKIE['googtrans'], '/en' ) !== false ) ? 'en_US' : 'bn_BD';
    $robots = 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    
    // 1. Robots Meta Tag Check
    if ( get_theme_mod( 'bug_mohol_seo_global_noindex', false ) || is_search() || is_404() ) {
        $robots = 'noindex, nofollow';
    }
    
    // 2. Resolve Meta Title & Description based on page context
    if ( is_front_page() || is_home() ) {
        // Homepage
        $custom_title = get_theme_mod( 'bug_mohol_seo_home_title', '' );
        $title = !empty( $custom_title ) ? $custom_title : $site_name . ' | ' . get_bloginfo( 'description' );
        
        $custom_desc = get_theme_mod( 'bug_mohol_seo_home_desc', '' );
        $description = !empty( $custom_desc ) ? $custom_desc : get_bloginfo( 'description' );
    } elseif ( is_singular() ) {
        // Individual post / page
        $title = get_the_title() . ' | ' . $site_name;
        
        // Excerpt or content-fallback for description
        if ( has_excerpt( $post->ID ) ) {
            $description = wp_strip_all_tags( get_the_excerpt() );
        } else {
            $content = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
            $description = wp_html_excerpt( $content, 155 );
        }
        
        $type = 'article';
        
        // Post featured image
        if ( has_post_thumbnail( $post->ID ) ) {
            $image_url = get_the_post_thumbnail_url( $post->ID, 'full' );
        }
    } else {
        // Categories, tags, archives
        $title = wp_strip_all_tags( get_the_archive_title() ) . ' | ' . $site_name;
        $description = wp_strip_all_tags( get_the_archive_description() );
        if ( empty( $description ) ) {
            $description = sprintf( esc_html__( 'Browse our archive for %s articles.', 'bug-mohol' ), wp_strip_all_tags( get_the_archive_title() ) );
        }
    }
    
    // Escape outputs safely
    $title_escaped = esc_attr( $title );
    $description_escaped = esc_attr( $description );
    $image_escaped = esc_url( $image_url );
    $url_escaped = esc_url( $url );
    
    // Output HTML Tags
    echo "\n" . '<!-- Dynamic Pro SEO Meta Tags -->' . "\n";
    echo '<meta name="robots" content="' . esc_attr( $robots ) . '" />' . "\n";
    echo '<meta name="description" content="' . $description_escaped . '" />' . "\n";
    
    // Open Graph Tags
    echo '<meta property="og:locale" content="' . esc_attr( $locale ) . '" />' . "\n";
    echo '<meta property="og:type" content="' . esc_attr( $type ) . '" />' . "\n";
    echo '<meta property="og:title" content="' . $title_escaped . '" />' . "\n";
    echo '<meta property="og:description" content="' . $description_escaped . '" />' . "\n";
    echo '<meta property="og:url" content="' . $url_escaped . '" />' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr( $site_name ) . '" />' . "\n";
    if ( !empty( $image_url ) ) {
        echo '<meta property="og:image" content="' . $image_escaped . '" />' . "\n";
        echo '<meta property="og:image:secure_url" content="' . $image_escaped . '" />' . "\n";
    }
    
    // Twitter Card Tags
    echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
    echo '<meta name="twitter:title" content="' . $title_escaped . '" />' . "\n";
    echo '<meta name="twitter:description" content="' . $description_escaped . '" />' . "\n";
    if ( !empty( $image_url ) ) {
        echo '<meta name="twitter:image" content="' . $image_escaped . '" />' . "\n";
    }
    
    // Alternate hreflang (En & Bn crawler-safe indexable targets)
    $clean_url_en = add_query_arg( 'lang', 'en', home_url( $GLOBALS['wp']->request ) );
    $clean_url_bn = add_query_arg( 'lang', 'bn', home_url( $GLOBALS['wp']->request ) );
    echo '<link rel="alternate" hreflang="bn" href="' . esc_url( $clean_url_bn ) . '" />' . "\n";
    echo '<link rel="alternate" hreflang="en" href="' . esc_url( $clean_url_en ) . '" />' . "\n";
    echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $clean_url_bn ) . '" />' . "\n";
    
    // Sitemap Link
    $sitemap_url = get_theme_mod( 'bug_mohol_seo_sitemap_url', '' );
    if ( empty( $sitemap_url ) ) {
        $sitemap_url = home_url( '/wp-sitemap.xml' );
    }
    echo '<link rel="sitemap" type="application/xml" title="Sitemap" href="' . esc_url( $sitemap_url ) . '" />' . "\n";
    
    // JSON-LD Schemas Output
    echo "\n" . '<!-- Dynamic Pro SEO JSON-LD Schemas -->' . "\n";
    
    // 1. WebSite Schema + SearchAction (Homepage only)
    if ( is_front_page() || is_home() ) {
        $website_schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => $site_name,
            'url' => home_url( '/' ),
            'potentialAction' => array(
                '@type' => 'SearchAction',
                'target' => home_url( '/?s={search_term_string}' ),
                'query-input' => 'required name=search_term_string'
            )
        );
        echo '<script type="application/ld+json">' . json_encode( $website_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
    
    // 2. BreadcrumbList Schema (Singular posts and archives)
    if ( is_singular() || is_archive() ) {
        $breadcrumbs = array(
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => array()
        );
        
        // Home
        $breadcrumbs['itemListElement'][] = array(
            '@type' => 'ListItem',
            'position' => 1,
            'name' => esc_html__( 'প্রচ্ছদ', 'bug-mohol' ),
            'item' => home_url( '/' )
        );
        
        if ( is_singular( 'post' ) ) {
            $categories = get_the_category( $post->ID );
            if ( !empty( $categories ) ) {
                $category = $categories[0];
                $breadcrumbs['itemListElement'][] = array(
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => esc_html( $category->name ),
                    'item' => get_category_link( $category->term_id )
                );
                
                $breadcrumbs['itemListElement'][] = array(
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => esc_html( get_the_title() ),
                    'item' => get_permalink( $post->ID )
                );
            }
        } elseif ( is_archive() ) {
            $breadcrumbs['itemListElement'][] = array(
                '@type' => 'ListItem',
                'position' => 2,
                'name' => wp_strip_all_tags( get_the_archive_title() ),
                'item' => $url
            );
        } else {
            $breadcrumbs['itemListElement'][] = array(
                '@type' => 'ListItem',
                'position' => 2,
                'name' => esc_html( get_the_title() ),
                'item' => get_permalink( $post->ID )
            );
        }
        
        echo '<script type="application/ld+json">' . json_encode( $breadcrumbs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
    
    // 3. NewsArticle / Article Schema (Singular posts only)
    if ( is_singular( 'post' ) ) {
        $author_id = $post->post_author;
        $article_schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'NewsArticle',
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id' => get_permalink( $post->ID )
            ),
            'headline' => esc_html( get_the_title() ),
            'datePublished' => get_the_date( 'c', $post->ID ),
            'dateModified' => get_the_modified_date( 'c', $post->ID ),
            'author' => array(
                '@type' => 'Person',
                'name' => esc_html( get_the_author_meta( 'display_name', $author_id ) ),
                'url' => get_author_posts_url( $author_id )
            ),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => $site_name,
                'logo' => array(
                    '@type' => 'ImageObject',
                    'url' => has_custom_logo() ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' ) : ''
                )
            )
        );
        
        if ( has_post_thumbnail( $post->ID ) ) {
            $article_schema['image'] = array( get_the_post_thumbnail_url( $post->ID, 'full' ) );
        } elseif ( !empty( $image_url ) ) {
            $article_schema['image'] = array( $image_url );
        }
        
        echo '<script type="application/ld+json">' . json_encode( $article_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
}
add_action( 'wp_head', 'bug_mohol_seo_meta_tags', 5 );

/**
 * Override the document title for home page with custom Customizer title
 */
function bug_mohol_seo_custom_title( $title ) {
    if ( is_front_page() || is_home() ) {
        $custom_title = get_theme_mod( 'bug_mohol_seo_home_title', '' );
        if ( !empty( $custom_title ) ) {
            return $custom_title;
        }
    }
    return $title;
}
add_filter( 'pre_get_document_title', 'bug_mohol_seo_custom_title', 50 );



